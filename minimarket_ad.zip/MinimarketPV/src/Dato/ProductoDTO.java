/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

import java.math.BigDecimal;

/**
 *
 * @author Sistema
 */
public class ProductoDTO {
    private int id;
    private String nombre,codBarra,detalle, imagen;
    private BigDecimal precio;
    private boolean estado;
    private int idCateg;

    public ProductoDTO(int id, String nombre, String codBarra, String detalle, String imagen, BigDecimal precio, boolean estado, int idCateg) {
        this.id = id;
        this.nombre = nombre;
        this.codBarra = codBarra;
        this.detalle = detalle;
        this.imagen = imagen;
        this.precio = precio;
        this.estado = estado;
        this.idCateg = idCateg;
    }

    public ProductoDTO() {
        this.estado=true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodBarra() {
        return codBarra;
    }

    public void setCodBarra(String codBarra) {
        this.codBarra = codBarra;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getIdCateg() {
        return idCateg;
    }

    public void setIdCateg(int idCateg) {
        this.idCateg = idCateg;
    }
    
    
    
}
