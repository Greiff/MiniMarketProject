/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

/**
 *
 * @author Sistema
 */
public class RolDTO {
    private int id;
    private String nombre;
    private boolean regVenta,regIng,regProd,regProv,regCli,regCat,regLote,regRol,anularVenta,anularIng,infoVenta,infoIngreso,respaldarBD,restaurarBD,infoCaja;

    public RolDTO(String nombre, String descripcion) {
        this.nombre = nombre;


    }

    public RolDTO(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    
    

    public RolDTO() {
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String toString(){
        return nombre;
    }

    public boolean isRegVenta() {
        return regVenta;
    }

    public void setRegVenta(boolean regVenta) {
        this.regVenta = regVenta;
    }

    public boolean isRegIng() {
        return regIng;
    }

    public void setRegIng(boolean regIng) {
        this.regIng = regIng;
    }

    public boolean isRegProd() {
        return regProd;
    }

    public void setRegProd(boolean regProd) {
        this.regProd = regProd;
    }

    public boolean isRegProv() {
        return regProv;
    }

    public void setRegProv(boolean regProv) {
        this.regProv = regProv;
    }

    public boolean isRegCli() {
        return regCli;
    }

    public void setRegCli(boolean regCli) {
        this.regCli = regCli;
    }

    public boolean isRegCat() {
        return regCat;
    }

    public void setRegCat(boolean regCat) {
        this.regCat = regCat;
    }

    public boolean isRegLote() {
        return regLote;
    }

    public void setRegLote(boolean regLote) {
        this.regLote = regLote;
    }

    public boolean isRegRol() {
        return regRol;
    }

    public void setRegRol(boolean regRol) {
        this.regRol = regRol;
    }

    public boolean isAnularVenta() {
        return anularVenta;
    }

    public void setAnularVenta(boolean anularVenta) {
        this.anularVenta = anularVenta;
    }

    public boolean isAnularIng() {
        return anularIng;
    }

    public void setAnularIng(boolean anularIng) {
        this.anularIng = anularIng;
    }

    public boolean isInfoVenta() {
        return infoVenta;
    }

    public void setInfoVenta(boolean infoVenta) {
        this.infoVenta = infoVenta;
    }

    public boolean isInfoIngreso() {
        return infoIngreso;
    }

    public void setInfoIngreso(boolean infoIngreso) {
        this.infoIngreso = infoIngreso;
    }

    public boolean isRespaldarBD() {
        return respaldarBD;
    }

    public void setRespaldarBD(boolean respaldarBD) {
        this.respaldarBD = respaldarBD;
    }

    public boolean isRestaurarBD() {
        return restaurarBD;
    }

    public void setRestaurarBD(boolean restaurarBD) {
        this.restaurarBD = restaurarBD;
    }

    public boolean isInfoCaja() {
        return infoCaja;
    }

    public void setInfoCaja(boolean infoCaja) {
        this.infoCaja = infoCaja;
    }
    
    
}
