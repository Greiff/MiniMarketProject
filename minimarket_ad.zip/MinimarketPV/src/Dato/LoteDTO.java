/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

import java.sql.Date;

/**
 *
 * @author Sistema
 */
public class LoteDTO {
    private int id;
    private String serie;
    private Date fechaVen;
    private boolean estado;
    private int idProd;

    public LoteDTO(int id, String serie, Date fechaVen, boolean estado, int idProd) {
        this.id = id;
        this.serie = serie;
        this.fechaVen = fechaVen;
        this.estado = estado;
        this.idProd = idProd;
    }

 

    public LoteDTO() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public Date getFechaVen() {
        return fechaVen;
    }

    public void setFechaVen(Date fechaVen) {
        this.fechaVen = fechaVen;
    }

    public int getIdProd() {
        return idProd;
    }

    public void setIdProd(int idProd) {
        this.idProd = idProd;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
}
