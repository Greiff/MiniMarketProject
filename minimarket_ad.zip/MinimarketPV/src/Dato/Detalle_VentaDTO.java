/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

import java.math.BigDecimal;

/**
 *
 * @author Sistema
 */
public class Detalle_VentaDTO {
    private int id,cantidad;
    private BigDecimal precio,descuento;
    private int idProd,idVenta,idStock;

    public Detalle_VentaDTO(int id, int cantidad, BigDecimal precio, BigDecimal descuento, int idProd, int idVenta, int idAlma) {
        this.id = id;
        this.cantidad = cantidad;
        this.precio = precio;
        this.descuento = descuento;
        this.idProd = idProd;
        this.idVenta = idVenta;
        this.idStock = idAlma;
    }

    public Detalle_VentaDTO() {
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public BigDecimal getDescuento() {
        return descuento;
    }

    public void setDescuento(BigDecimal descuento) {
        this.descuento = descuento;
    }

    public int getIdProd() {
        return idProd;
    }

    public void setIdProd(int idProd) {
        this.idProd = idProd;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public int getIdStock() {
        return idStock;
    }

    public void setIdStock(int idStock) {
        this.idStock = idStock;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
}



