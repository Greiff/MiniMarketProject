/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

/**
 *
 * @author Sistema
 */
public class Stock_AlmacenDTO {
    private int id,stock;
    private int idProd,idAlma;

    public Stock_AlmacenDTO(int id, int stock, int idProd, int idAlma) {
        this.id = id;
        this.stock = stock;
        this.idProd = idProd;
        this.idAlma = idAlma;
    }

    public Stock_AlmacenDTO() {
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getIdProd() {
        return idProd;
    }

    public void setIdProd(int idProd) {
        this.idProd = idProd;
    }

    public int getIdAlma() {
        return idAlma;
    }

    public void setIdAlma(int idAlma) {
        this.idAlma = idAlma;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
}
