/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dato;

import java.math.*;
import java.sql.Date;



/**
 *
 * @author Sistema
 */
public class VentaDTO {
    private int id;
    private int idPersona,idUsuario;
    private String tipo,serie,numero;
    private BigDecimal impuesto,total;
    private Date fecha;

    public VentaDTO() {
    }

    public VentaDTO(int id, int idPersona, int idUsuario, String tipo, String serie, String numero, BigDecimal impuesto, BigDecimal total, Date fecha) {
        this.id = id;
        this.idPersona = idPersona;
        this.idUsuario = idUsuario;
        this.tipo = tipo;
        this.serie = serie;
        this.numero = numero;
        this.impuesto = impuesto;
        this.total = total;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public BigDecimal getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(BigDecimal impuesto) {
        this.impuesto = impuesto;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public  Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    
}
