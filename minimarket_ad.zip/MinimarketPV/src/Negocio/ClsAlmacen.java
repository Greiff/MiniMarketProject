/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import DAO.AlmacenDAO;
import Dato.AlmacenDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class ClsAlmacen {

    public ClsAlmacen() {
    }
    
    public List<AlmacenDTO> MostrarTodos() throws Exception{
        
        AlmacenDAO metodo = new AlmacenDAO();

        List<AlmacenDTO> lista = metodo.readAll();
                 

        return lista;
    }
     
      public List<Object[]> MostrarSinFiltro() throws Exception{
        
        AlmacenDAO metodo =new AlmacenDAO();
        
        List<Object[]> lista = new ArrayList();
        
        lista = metodo.SinFiltros();

        return lista;
    }
    
    public List<Object[]> buscar(String palabra){
        
        AlmacenDAO metodo =new AlmacenDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra);
        } catch (SQLException ex) {
            Logger.getLogger(ClsAlmacen.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
     public List<Object[]> buscarID(int palabra){
        AlmacenDAO metodo =new AlmacenDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscarID(palabra);
        } catch (SQLException ex) {
            Logger.getLogger(ClsAlmacen.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
     
    public boolean GuardarNuevo(AlmacenDTO alma){
        AlmacenDAO metodo =new AlmacenDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(alma);
            } catch (Exception ex) {
                Logger.getLogger(ClsAlmacen.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(AlmacenDTO alma){
        AlmacenDAO metodo =new AlmacenDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(alma);
            } catch (Exception ex) {
                Logger.getLogger(ClsAlmacen.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public AlmacenDTO recuperarAlmacen (int codAlma){

        AlmacenDAO metodo =new AlmacenDAO();
        AlmacenDTO alma= new AlmacenDTO();
        
        try {
           alma = metodo.read(codAlma);
        } catch (Exception ex) {
            Logger.getLogger(ClsAlmacen.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return alma;
    }
    
    public boolean Eliminar (int codAlma){
        AlmacenDAO metodo =new AlmacenDAO(); 
          
        return metodo.delete(codAlma);
    }
}
