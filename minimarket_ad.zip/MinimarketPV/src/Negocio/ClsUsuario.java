/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Dato.UsuarioDTO;
import DAO.UsuarioDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Sistema
 */
public class ClsUsuario {

    public ClsUsuario() {
    }
    
    public boolean VerficarUsuario(String user,String pass) throws Exception{
        UsuarioDAO metodo =new UsuarioDAO();
        List<UsuarioDTO> lista = new ArrayList();
        lista = metodo.readAll();
        for (int i=0;i<lista.size();i++){
            if(user.equalsIgnoreCase(lista.get(i).getUser())
                    && pass.equalsIgnoreCase(lista.get(i).getPass())){
                return true;
            }
        }     
        return false;
    }
    
    public List<Object[]> MostrarSinFiltro(boolean verInactivos) throws Exception{
        
        UsuarioDAO metodo =new UsuarioDAO();
        
        List<Object[]> lista = new ArrayList();
        
        lista = metodo.SinFiltros(verInactivos);

        return lista;
    }
    
    public List<Object[]> buscar(String palabra,boolean verInactivos){
        
        UsuarioDAO metodo =new UsuarioDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,verInactivos);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
     public List<Object[]> buscarDni(int palabra,boolean verInactivos){
        UsuarioDAO metodo =new UsuarioDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscarDni(palabra,verInactivos);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
     
    public boolean GuardarNuevo(UsuarioDTO usuario){
        UsuarioDAO metodo =new UsuarioDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(usuario);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(UsuarioDTO usuario){
        UsuarioDAO metodo =new UsuarioDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(usuario);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public UsuarioDTO recuperarUsuario (int codUsuario){

        UsuarioDAO metodo =new UsuarioDAO();
        UsuarioDTO usuario= new UsuarioDTO();
        
        try {
            usuario = metodo.read(codUsuario);
        } catch (Exception ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return usuario;
    }
    
    public boolean Eliminar (int codUsuario){
        UsuarioDAO metodo =new UsuarioDAO(); 
        return metodo.delete(codUsuario);   
    }
}
