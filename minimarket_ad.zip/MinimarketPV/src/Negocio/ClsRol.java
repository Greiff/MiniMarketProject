/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import DAO.RolDAO;
import Dato.RolDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class ClsRol {

    public ClsRol() {
    }
    
     public List<RolDTO> MostrarTodos() throws Exception{
        
        RolDAO metodo = new RolDAO();

        List<RolDTO> lista = metodo.readAll();
                 

        return lista;
    }
     
      public List<Object[]> MostrarSinFiltro() throws Exception{
        
        RolDAO metodo =new RolDAO();
        
        List<Object[]> lista = new ArrayList();
        
        lista = metodo.SinFiltros();

        return lista;
    }
    
    public List<Object[]> buscar(String palabra){
        
        RolDAO metodo =new RolDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
     public List<Object[]> buscarID(int palabra){
        RolDAO metodo =new RolDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscarID(palabra);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
     
    public boolean GuardarNuevo(RolDTO rol){
        RolDAO metodo =new RolDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(rol);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(RolDTO rol){
        RolDAO metodo =new RolDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(rol);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public RolDTO recuperarRol (int codRol){

        RolDAO metodo =new RolDAO();
        RolDTO rol= new RolDTO();
        
        try {
            rol = metodo.read(codRol);
        } catch (Exception ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return rol;
    }
    
    public boolean Eliminar (int codRol){
        RolDAO metodo =new RolDAO(); 
          
        return metodo.delete(codRol);
    }
}
