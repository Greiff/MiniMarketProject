/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;


import DAO.PersonaDAO;
import Dato.PersonaDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class ClsPersona {

    public ClsPersona() {
    }
      
    
    public List<Object[]> MostrarSinFiltro(boolean verInactivos,String tipo) throws Exception{
        
        PersonaDAO metodo =new PersonaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        lista = metodo.SinFiltros(verInactivos,tipo);

        return lista;
    }
    
    public List<Object[]> buscar(String palabra,boolean verInactivos,String tipo){
        
        PersonaDAO metodo =new PersonaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,verInactivos,tipo);
        } catch (SQLException ex) {
            Logger.getLogger(ClsPersona.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
     public List<Object[]> buscarDni(int palabra,boolean verInactivos,String tipo){
        PersonaDAO metodo =new PersonaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscarDni(palabra,verInactivos,tipo);
        } catch (SQLException ex) {
            Logger.getLogger(ClsPersona.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
     
    public boolean GuardarNuevo(PersonaDTO cliente){
        PersonaDAO metodo =new PersonaDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(cliente);
            } catch (Exception ex) {
                Logger.getLogger(ClsPersona.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(PersonaDTO cliente){
        PersonaDAO metodo =new PersonaDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(cliente);
            } catch (Exception ex) {
                Logger.getLogger(ClsPersona.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public PersonaDTO recuperarPersona (int codCliente){

        PersonaDAO metodo =new PersonaDAO();
        PersonaDTO usuario= new PersonaDTO();
        
        try {
            usuario = metodo.read(codCliente);
        } catch (Exception ex) {
            Logger.getLogger(ClsPersona.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return usuario;
    }
    
    public boolean Eliminar (int codCliente){
        PersonaDAO metodo =new PersonaDAO(); 
        return metodo.delete(codCliente);   
    }
}
