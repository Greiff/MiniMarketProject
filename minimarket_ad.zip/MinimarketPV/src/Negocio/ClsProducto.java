/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import DAO.ProductoDAO;
import Dato.ProductoDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class ClsProducto {

    public ClsProducto() {
    }
    
    public List<ProductoDTO> MostrarTodos() throws Exception{
        
        ProductoDAO metodo = new ProductoDAO();

        List<ProductoDTO> lista = metodo.readAll();
                 

        return lista;
    }
    

    public boolean GuardarNuevo(ProductoDTO alma){
        ProductoDAO metodo =new ProductoDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(alma);
            } catch (Exception ex) {
                Logger.getLogger(ClsProducto.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(ProductoDTO prod){
        ProductoDAO metodo =new ProductoDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(prod);
            } catch (Exception ex) {
                Logger.getLogger(ClsProducto.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public ProductoDTO recuperarAlmacen (int codprod){

        ProductoDAO metodo =new ProductoDAO();
        ProductoDTO alma= new ProductoDTO();
        
        try {
           alma = metodo.read(codprod);
        } catch (Exception ex) {
            Logger.getLogger(ClsProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return alma;
    }
    
    public boolean Eliminar (int codprod){
        ProductoDAO metodo =new ProductoDAO(); 
          
        return metodo.delete(codprod);
    }
}
