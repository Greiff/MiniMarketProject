/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import DAO.CategoriaDAO;
import DAO.RolDAO;
import Dato.CategoriaDTO;
import Dato.RolDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class ClsCategoria {
    
    public ClsCategoria() {
    }
    
     public List<CategoriaDTO> MostrarTodos() throws Exception{
        
        CategoriaDAO metodo = new CategoriaDAO();

        List<CategoriaDTO> lista = metodo.readAll();
                 

        return lista;
    }
     
      public List<Object[]> MostrarSinFiltro(boolean verInactivos) throws Exception{
        
        CategoriaDAO metodo =new CategoriaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        lista = metodo.SinFiltros(verInactivos);

        return lista;
    }
    
    public List<Object[]> buscar(String palabra,boolean verInactivos){
        
        CategoriaDAO metodo =new CategoriaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,verInactivos);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
     public List<Object[]> buscarID(int palabra,boolean verInactivos){
        CategoriaDAO metodo =new CategoriaDAO();
        
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscarID(palabra,verInactivos);
        } catch (SQLException ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
     
    public boolean GuardarNuevo(CategoriaDTO categoria){
        CategoriaDAO metodo =new CategoriaDAO();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(categoria);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(CategoriaDTO categoria){
        CategoriaDAO metodo =new CategoriaDAO();
        boolean verificar = false;
        

            try {
                verificar = metodo.update(categoria);
            } catch (Exception ex) {
                Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        return verificar;
    }
    
    public CategoriaDTO recuperarCategoria (int codCat){

        CategoriaDAO metodo =new CategoriaDAO();
        CategoriaDTO cat= new CategoriaDTO();
        
        try {
            cat = metodo.read(codCat);
        } catch (Exception ex) {
            Logger.getLogger(ClsUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cat;
    }
    
    public boolean Eliminar (int codCat){
        CategoriaDAO metodo =new CategoriaDAO(); 
          
        return metodo.delete(codCat);
    }
    
    
}
