/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import Conexion.*;
import Dato.*;
import Interfaz.*;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Sistema
 */
public class VentaDAO implements DAOgeneral<VentaDTO>{

    private static final String SQL_INSERT="INSERT INTO venta(tipo_venta,serie_venta,num_venta,"
            + "fecha_venta,impuesto_venta,total_venta,id_persona,id_usuario)"
            + " VALUES(?,?,?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM venta WHERE id_venta = ? ";
    private static final String SQL_UPDATE="UPDATE venta SET tipo_venta=?,serie_venta=?,num_venta=?,"
            + "fecha_venta=?,impuesto_venta=?,total_venta=?,id_persona=?,id_usuario=? "
            + " WHERE id_venta = ?";
    private static final String SQL_READ="SELECT * FROM venta WHERE id_venta = ?";
    private static final String SQL_READALL="SELECT * FROM venta";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(VentaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getTipo());
            st.setString(2, c.getSerie());
            st.setString(3, c.getNumero());
            st.setDate(4, c.getFecha());
            st.setBigDecimal(5, c.getImpuesto());
            st.setBigDecimal(6, c.getTotal());
            st.setInt(7, c.getIdPersona());
            st.setInt(8, c.getIdUsuario()); 
           
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(VentaDTO c) throws Exception {
        PreparedStatement st;
        Date fecha; 
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            st.setString(1, c.getTipo());
            st.setString(2, c.getSerie());
            st.setString(3, c.getNumero());        
            st.setDate(4, c.getFecha());
            st.setBigDecimal(5, c.getImpuesto());
            st.setBigDecimal(6, c.getTotal());
            st.setInt(7, c.getIdPersona());
            st.setInt(8, c.getIdUsuario()); 
            st.setInt(9, c.getId());
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public VentaDTO read(Object key) throws Exception {
        PreparedStatement st;
        ResultSet rs;
        VentaDTO venta = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                venta= new VentaDTO();
                venta.setId(rs.getInt(1));
                venta.setTipo(rs.getString(2));
                venta.setSerie(rs.getString(3));
                venta.setNumero(rs.getString(4));
                venta.setFecha(rs.getDate(5));
                venta.setImpuesto(rs.getBigDecimal(6));
                venta.setTotal(rs.getBigDecimal(7));
                venta.setIdPersona(rs.getInt(8));
                venta.setIdUsuario(rs.getInt(9));
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return venta;
    }

    @Override
    public List<VentaDTO> readAll() throws Exception {
        ArrayList<VentaDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                VentaDTO venta= new VentaDTO();
                venta.setId(Integer.valueOf(rs.getString(1)));
                venta.setTipo(rs.getString(2));
                venta.setSerie(rs.getString(3));
                venta.setNumero(rs.getString(4));
                venta.setFecha(rs.getDate(5));
                venta.setImpuesto(rs.getBigDecimal(6));
                venta.setTotal(rs.getBigDecimal(7));
                venta.setIdPersona(rs.getInt(8));
                venta.setIdUsuario(rs.getInt(9));
                lista.add(venta);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    
}
