/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.Detalle_VentaDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class Detalle_VentaDAO implements DAOgeneral<Detalle_VentaDTO>{
    private static final String SQL_INSERT="INSERT INTO detalle_venta(cantidad_detventa,precio_detventa,descuento_detventa,id_prod,id_venta,id_stock) VALUES(?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM detalle_venta WHERE id_det_venta = ? ";
    private static final String SQL_UPDATE="UPDATE detalle_venta SET cantidad_detventa=?,precio_detventa=?,descuento_detventa=?,id_prod=?,id_venta=?,id_stock=? WHERE id_det_venta = ?";
    private static final String SQL_READ="SELECT * FROM detalle_venta WHERE id_det_venta = ?";
    private static final String SQL_READALL="SELECT * FROM detalle_venta";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean create(Detalle_VentaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setInt(1, c.getCantidad());
            st.setBigDecimal(2, c.getPrecio());
            st.setBigDecimal(3, c.getDescuento());
            st.setInt(4, c.getIdProd());
            st.setInt(5, c.getIdVenta());
            st.setInt(6, c.getIdStock());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(Detalle_VentaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setInt(1, c.getCantidad());
            st.setBigDecimal(2, c.getPrecio());
            st.setBigDecimal(3, c.getDescuento());
            st.setInt(4, c.getIdProd());
            st.setInt(5, c.getIdVenta());
            st.setInt(6, c.getIdStock());
             
            st.setInt(7, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public Detalle_VentaDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        Detalle_VentaDTO dv = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                dv = new Detalle_VentaDTO();
                dv.setId(rs.getInt(1));
                dv.setCantidad(rs.getInt(2));
                dv.setPrecio(rs.getBigDecimal(3));
                dv.setDescuento(rs.getBigDecimal(4));
                dv.setIdProd(rs.getInt(5));
                dv.setIdVenta(rs.getInt(6));
                dv.setIdStock(rs.getInt(7));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return dv;
    }
    
    @Override
    public List<Detalle_VentaDTO> readAll() throws Exception {
      
        ArrayList<Detalle_VentaDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
               Detalle_VentaDTO dv = new Detalle_VentaDTO();
                dv.setId(rs.getInt(1));
                dv.setCantidad(rs.getInt(2));
                dv.setPrecio(rs.getBigDecimal(3));
                dv.setDescuento(rs.getBigDecimal(4));
                dv.setIdProd(rs.getInt(5));
                dv.setIdVenta(rs.getInt(6));
                dv.setIdStock(rs.getInt(7));
                
                lista.add(dv);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
}
