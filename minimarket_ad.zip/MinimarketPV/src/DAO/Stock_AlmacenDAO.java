/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.CategoriaDTO;
import Dato.Stock_AlmacenDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class Stock_AlmacenDAO implements DAOgeneral<Stock_AlmacenDTO>{
    
    private static final String SQL_INSERT="INSERT INTO stock_almacen(stock_almacen,id_prod,id_alma) VALUES(?,?,?)";
    private static final String SQL_DELETE="DELETE FROM stock_almacen WHERE id_stock_alma = ? ";
    private static final String SQL_UPDATE="UPDATE stock_almacen SET stock_almacen=?,id_prod=?,id_alma=? WHERE id_stock_alma = ?";
    private static final String SQL_READ="SELECT * FROM stock_almacen WHERE id_stock_alma = ?";
    private static final String SQL_READALL="SELECT * FROM stock_almacen";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean create(Stock_AlmacenDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setInt(1, c.getStock());
            st.setInt(2, c.getIdProd());
            st.setInt(3, c.getIdAlma());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(Stock_AlmacenDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setInt(1, c.getStock());
            st.setInt(2, c.getIdProd());
            st.setInt(3, c.getIdAlma());

            
            st.setInt(4, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public Stock_AlmacenDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        Stock_AlmacenDTO sa = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                sa = new Stock_AlmacenDTO();
                sa.setId(rs.getInt(1));
                sa.setStock(rs.getInt(2));
                sa.setIdProd(rs.getInt(3));
                sa.setIdAlma(rs.getInt(4));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return sa;
    }
    
    @Override
    public List<Stock_AlmacenDTO> readAll() throws Exception {
      
        ArrayList<Stock_AlmacenDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                Stock_AlmacenDTO sa = new Stock_AlmacenDTO();
                sa.setId(rs.getInt(1));
                sa.setStock(rs.getInt(2));
                sa.setIdProd(rs.getInt(3));
                sa.setIdAlma(rs.getInt(4));
                
                lista.add(sa);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
}
