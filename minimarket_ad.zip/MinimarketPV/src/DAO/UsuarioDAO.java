/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.*;
import Dato.*;
import Interfaz.*;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Sistema
 */
public class UsuarioDAO implements DAOgeneral<UsuarioDTO>{

    private static final String SQL_INSERT="INSERT INTO usuario(nombre_u,apellido_u,tipo_doc_u,"
            + "num_doc_u,email_u,user_u,password_u,estado_u,direccion_u,"
            + "telefono_u,id_rol_u,fecha_nac_u) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM usuario WHERE id_usuario = ? ";
    private static final String SQL_UPDATE="UPDATE usuario SET nombre_u= ?,apellido_u= ?,tipo_doc_u =?,"
            + "num_doc_u = ?,email_u  = ?,user_u = ?,password_u =?,estado_u =?,direccion_u =?,"
            + "telefono_u = ?,id_rol_u = ?,fecha_nac_u=?  WHERE id_usuario = ?";
    private static final String SQL_READ="SELECT * FROM usuario WHERE id_usuario = ?";
    private static final String SQL_READALL="SELECT * FROM usuario";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean create(UsuarioDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setString(2, c.getApellido());
            st.setString(3, c.getTipoDoc());
            st.setInt(4, c.getNumDoc());
            st.setString(5, c.getEmail());
            st.setString(6, c.getUser());
            st.setString(7, c.getPass());
            st.setBoolean(8, c.getEstado());
            st.setString(9, c.getDireccion());
            st.setString(10, c.getTelefono());
            st.setInt(11, c.getIdRol());
            st.setDate(12, c.getFechaNac());
           
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(UsuarioDTO c) throws Exception {
        PreparedStatement st;

        try{ 

            st = con.getConexion().prepareStatement(SQL_UPDATE);

            st.setString(1, c.getNombre());
            st.setString(2, c.getApellido());
            st.setString(3, c.getTipoDoc());
            st.setInt(4, c.getNumDoc());
            st.setString(5, c.getEmail());
            st.setString(6, c.getUser());
            st.setString(7, c.getPass());
            st.setBoolean(8, c.getEstado());
            st.setString(9, c.getDireccion());
            st.setString(10, c.getTelefono());
            st.setInt(11, c.getIdRol());
            st.setDate(12, c.getFechaNac());
            st.setInt(13, c.getId());
                
            
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
            
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key){
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(NumberFormatException | SQLException e){
            System.out.println("no se pudo eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public UsuarioDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        UsuarioDTO user = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                user= new UsuarioDTO();
                user.setId(rs.getInt(1));
                user.setNombre(rs.getString(2));
                user.setTelefono(rs.getString(9));
                user.setApellido(rs.getString(3));
                user.setDireccion(rs.getString(8));
                user.setEmail(rs.getString(7));
                user.setEstado(rs.getBoolean(12));
                user.setIdRol(rs.getInt(13));
                user.setTipoDoc(rs.getString(4));
                user.setNumDoc(rs.getInt(5));
                user.setUser(rs.getString(10));
                user.setPass(rs.getString(11));
                user.setFechaNac(rs.getDate(6));
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return user;
    }
    
    @Override
    public List<UsuarioDTO> readAll() throws Exception {
      
        ArrayList<UsuarioDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                UsuarioDTO user= new UsuarioDTO();
                user.setId(rs.getInt("id_usuario"));
                user.setNombre(rs.getString("nombre_u"));
                user.setTelefono(rs.getString("telefono_u"));
                user.setApellido(rs.getString("apellido_u"));
                user.setDireccion(rs.getString("direccion_u"));
                user.setEmail(rs.getString("email_u"));
                user.setEstado(rs.getBoolean("estado_u"));
                user.setIdRol(rs.getInt("id_rol_u"));
                user.setTipoDoc(rs.getString("tipo_doc_u"));
                user.setNumDoc(rs.getInt("num_doc_u"));
                user.setUser(rs.getString("user_u"));
                user.setPass(rs.getString("password_u"));    
                user.setFechaNac(rs.getDate("fecha_nac_u"));
                
                lista.add(user);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    public List<Object[]> buscar(String palabra,boolean verInactivos) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("call BuscarPorNomUsuario(?)");
            st.setString(1, palabra);   
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM usuario_rol WHERE nombre_u like concat('%',?,'%') AND  estado_u = ? ");
            st.setString(1, palabra);
            st.setBoolean(2, true);
            }
           
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] user = new Object[16];
                user[0] = rs.getInt(1);
                user[1]=rs.getString(2);
                user[2]=rs.getString(3);
                user[3]=rs.getString(4);
                user[4]=rs.getInt(5);
                user[5]=rs.getDate(6);
                user[6]=rs.getString(7);
                user[7]=rs.getString(8);
                user[8]=rs.getString(9);
                user[9]=rs.getString(10);
                user[10]=rs.getString(11);
                user[11]=rs.getBoolean(12);    
                user[12]=rs.getInt(13);
                user[13]=rs.getInt(14);
                user[14]=rs.getString(15);
                user[15]=rs.getString(16);
                
                lista.add(user);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> buscarDni(int palabra,boolean verInactivos) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("call BuscarPorDNIUsuario(?)");
            st.setInt(1, palabra);   
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM usuario_rol WHERE num_doc_u = ? AND  estado_u = ? ");
            st.setInt(1, palabra);
            st.setBoolean(2, true);
            }
            
            
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] user = new Object[16];
                user[0] = rs.getInt(1);
                user[1]=rs.getString(2);
                user[2]=rs.getString(3);
                user[3]=rs.getString(4);
                user[4]=rs.getInt(5);
                user[5]=rs.getDate(6);
                user[6]=rs.getString(7);
                user[7]=rs.getString(8);
                user[8]=rs.getString(9);
                user[9]=rs.getString(10);
                user[10]=rs.getString(11);
                user[11]=rs.getBoolean(12);    
                user[12]=rs.getInt(13);
                user[13]=rs.getInt(14);
                user[14]=rs.getString(15);
                user[15]=rs.getString(16);
                
                lista.add(user);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> SinFiltros(boolean verInactivos) throws Exception {
      
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{   
            if(verInactivos){
            st = con.getConexion().prepareStatement("select * from usuario_rol");
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM usuario_rol WHERE estado_u = ?");
            st.setBoolean(1, true);
            }
            
            
            
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] user = new Object[16];
                user[0] = rs.getInt(1);
                user[1]=rs.getString(2);
                user[2]=rs.getString(3);
                user[3]=rs.getString(4);
                user[4]=rs.getInt(5);
                user[5]=rs.getDate(6);
                user[6]=rs.getString(7);
                user[7]=rs.getString(8);
                user[8]=rs.getString(9);
                user[9]=rs.getString(10);
                user[10]=rs.getString(11);
                user[11]=rs.getBoolean(12);    
                user[12]=rs.getInt(13);
                user[13]=rs.getInt(14);
                user[14]=rs.getString(15);
                user[15]=rs.getString(16);
               
                
                
                lista.add(user);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
}
