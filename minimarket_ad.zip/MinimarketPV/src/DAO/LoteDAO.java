/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.LoteDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class LoteDAO implements DAOgeneral<LoteDTO>{
    
    private static final String SQL_INSERT="INSERT INTO lote(serie_lote,fecha_venc_lote,estado_cag,id_prod) VALUES(?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM lote WHERE id_lote = ?";
    private static final String SQL_UPDATE="UPDATE lote SET serie_lote=?,fecha_venc_lote=?,estado_cag=?,id_prod=? WHERE id_lote = ?";
    private static final String SQL_READ="SELECT * FROM lote WHERE id_lote = ?";
    private static final String SQL_READALL="SELECT * FROM lote";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(LoteDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getSerie());
            st.setDate(2, c.getFechaVen());
            st.setBoolean(3, c.getEstado());
            st.setInt(4, c.getIdProd());
            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(LoteDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setString(1, c.getSerie());
            st.setDate(2, c.getFechaVen());
            st.setBoolean(3, c.getEstado());
            st.setInt(4, c.getIdProd());
            
            st.setInt(5, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public LoteDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        LoteDTO lote = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                lote = new LoteDTO();
                lote.setId(rs.getInt(1));
                lote.setSerie(rs.getString(2));
                lote.setFechaVen(rs.getDate(3));
                lote.setEstado(rs.getBoolean(4));
                lote.setIdProd(rs.getInt(5));
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lote;
    }
    
    @Override
    public List<LoteDTO> readAll() throws Exception {
      
        ArrayList<LoteDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                LoteDTO lote = new LoteDTO();
                lote.setId(rs.getInt(1));
                lote.setSerie(rs.getString(2));
                lote.setFechaVen(rs.getDate(3));
                lote.setEstado(rs.getBoolean(4));
                lote.setIdProd(rs.getInt(5));
                
                lista.add(lote);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
}
