/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.CategoriaDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class CategoriaDAO implements DAOgeneral<CategoriaDTO>{
    private static final String SQL_INSERT="INSERT INTO categoria(nombre_categ,descripcion_categ,estado_categ) VALUES(?,?,?)";
    private static final String SQL_DELETE="DELETE FROM categoria WHERE id_categ = ?";
    private static final String SQL_UPDATE="UPDATE categoria SET nombre_categ=?,descripcion_categ=?,estado_categ=? WHERE id_categ = ?";
    private static final String SQL_READ="SELECT * FROM categoria WHERE id_categ= ?";
    private static final String SQL_READALL="SELECT * FROM categoria";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(CategoriaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setString(2, c.getDescripcion());
            st.setBoolean(3, c.getEstado());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(CategoriaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setString(1, c.getNombre());
            st.setString(2, c.getDescripcion());
            st.setBoolean(3, c.getEstado());

            
            st.setInt(4, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key){
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(NumberFormatException | SQLException e){
            System.out.println("No se puede eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public CategoriaDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        CategoriaDTO cate = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                cate = new CategoriaDTO();
                cate.setId(rs.getInt(1));
                cate.setNombre(rs.getString(2));
                cate.setDescripcion(rs.getString(3));
                cate.setEstado(rs.getBoolean(4));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return cate;
    }
    
    @Override
    public List<CategoriaDTO> readAll() throws Exception {
      
        ArrayList<CategoriaDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                CategoriaDTO cate = new CategoriaDTO();
                cate.setId(rs.getInt(1));
                cate.setNombre(rs.getString(2));
                cate.setDescripcion(rs.getString(3));
                cate.setEstado(rs.getBoolean(4));
                
                lista.add(cate);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
     public List<Object[]> buscar(String palabra,boolean verInactivos) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
             
            if(verInactivos){
            st = con.getConexion().prepareStatement("SELECT * FROM categoria WHERE nombre_categ like concat('%',?,'%')");
            st.setString(1, palabra);   
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM categoria WHERE nombre_categ like concat('%',?,'%') AND  estado_categ = ?");
            st.setString(1, palabra);
            st.setBoolean(2, true);
            }
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[4];
                rol[0] = rs.getInt(1);
                rol[1] = rs.getString(2);
                rol[2] = rs.getString(3);
                rol[3] = rs.getBoolean(4);
   
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> buscarID(int palabra,boolean verInactivos) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("SELECT * FROM categoria WHERE nombre_categ like concat('%',?,'%')");
            st.setInt(1, palabra);   
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM categoria WHERE nombre_categ like concat('%',?,'%') AND  estado_categ = ? ");
            st.setInt(1, palabra);
            st.setBoolean(2, true);
            }
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[4];
                rol[0] = rs.getInt(1);
                rol[1] = rs.getString(2);
                rol[2] = rs.getString(3);
                rol[3] = rs.getBoolean(4);
    
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> SinFiltros(boolean verInactivos) throws Exception {
      
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("SELECT * FROM categoria"); 
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM categoria WHERE estado_categ = ?");
            st.setBoolean(1, true);
            }
            
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[4];
                rol[0] = rs.getInt(1);
                rol[1]=rs.getString(2);
                rol[2]=rs.getString(3);
                rol[3]=rs.getBoolean(4);
               
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
}
