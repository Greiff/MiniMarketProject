/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.IngresoDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class IngresoDAO implements DAOgeneral<IngresoDTO>{
      private static final String SQL_INSERT="INSERT INTO ingreso(tipo_ing,serie_ing,num_ing,fecha_ing,impuesto_ing,total_ing,estado_ing,id_persona,id_usuario) VALUES(?,?,?,?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM ingreso WHERE id_ingreso = ?";
    private static final String SQL_UPDATE="UPDATE ingreso SET tipo_ing=?,serie_ing=?,num_ing=?,fecha_ing=?,impuesto_ing=?,total_ing=?,estado_ing=?,id_persona=?,id_usuario=? WHERE id_ingreso = ?";
    private static final String SQL_READ="SELECT * FROM ingreso WHERE id_ingreso = ?";
    private static final String SQL_READALL="SELECT * FROM ingreso";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(IngresoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getTipo());
            st.setString(2, c.getSerie());
            st.setString(3, c.getNum());
            st.setDate(4, c.getFecha());
            st.setBigDecimal(5, c.getImpuesto());
            st.setBigDecimal(6, c.getTotal());
            st.setBoolean(7, c.getEstado());
            st.setInt(8, c.getIdPersona());
            st.setInt(9, c.getIdUsuario());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(IngresoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setString(1, c.getTipo());
            st.setString(2, c.getSerie());
            st.setString(3, c.getNum());
            st.setDate(4, c.getFecha());
            st.setBigDecimal(5, c.getImpuesto());
            st.setBigDecimal(6, c.getTotal());
            st.setBoolean(7, c.getEstado());
            st.setInt(8, c.getIdPersona());
            st.setInt(9, c.getIdUsuario());


            
            st.setInt(10, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public IngresoDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        IngresoDTO ing = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                ing = new IngresoDTO();
                ing.setId(rs.getInt(1));
                ing.setTipo(rs.getString(2));
                ing.setSerie(rs.getString(3));
                ing.setNum(rs.getString(4));
                ing.setFecha(rs.getDate(5));
                ing.setImpuesto(rs.getBigDecimal(6));
                ing.setTotal(rs.getBigDecimal(7));
                ing.setEstado(rs.getBoolean(8));
                ing.setIdPersona(rs.getInt(9));
                ing.setIdUsuario(rs.getInt(10));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return ing;
    }
    
    @Override
    public List<IngresoDTO> readAll() throws Exception {
      
        ArrayList<IngresoDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                IngresoDTO ing = new IngresoDTO();
                ing.setId(rs.getInt(1));
                ing.setTipo(rs.getString(2));
                ing.setSerie(rs.getString(3));
                ing.setNum(rs.getString(4));
                ing.setFecha(rs.getDate(5));
                ing.setImpuesto(rs.getBigDecimal(6));
                ing.setTotal(rs.getBigDecimal(7));
                ing.setEstado(rs.getBoolean(8));
                ing.setIdPersona(rs.getInt(9));
                ing.setIdUsuario(rs.getInt(10));
                
                lista.add(ing);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
}
