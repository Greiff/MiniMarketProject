/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.PersonaDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class PersonaDAO implements DAOgeneral<PersonaDTO>{
    private static final String SQL_INSERT="INSERT INTO persona(tipo_per,tipo_doc_per,num_doc_per,direccion_per,telefono_per,email_per,estado_per,nombre_per,apellido_per,fecha_nac_per,sexo_per) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM persona WHERE id_persona = ? ";
    private static final String SQL_UPDATE="UPDATE persona SET tipo_per=?,tipo_doc_per=?,num_doc_per=?,direccion_per=?,telefono_per=?,email_per=?,estado_per=?,nombre_per=?,apellido_per=?,fecha_nac_per=?,sexo_per=?"
            + " WHERE id_persona = ?";
    private static final String SQL_READ="SELECT * FROM persona WHERE id_persona = ?";
    private static final String SQL_READALL="SELECT * FROM persona";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean create(PersonaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getTipo());
            st.setString(2, c.getTipoDoc());
            
            if(c.getNumDoc()==0){
                st.setNull(3, Types.INTEGER);
            }else{
                st.setInt(3, c.getNumDoc());
            }
             
            st.setString(4, c.getDireccion());
            st.setString(5, c.getTelefono());
            st.setString(6, c.getEmail());
            st.setBoolean(7, c.getEstado());
            st.setString(8, c.getNombre());
            st.setString(9, c.getApellido());
            st.setDate(10, c.getFechNac());
            st.setString(11, c.getSexo());
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(PersonaDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
             st.setString(1, c.getTipo());
            st.setString(2, c.getTipoDoc());
            
            if(c.getNumDoc()==0){
                st.setNull(3, Types.INTEGER);
            }else{
                st.setInt(3, c.getNumDoc());
            }
            
            st.setString(4, c.getDireccion());
            st.setString(5, c.getTelefono());
            st.setString(6, c.getEmail());
            st.setBoolean(7, c.getEstado());
            st.setString(8, c.getNombre());
            st.setString(9, c.getApellido());
            st.setDate(10, c.getFechNac());
            st.setString(11, c.getSexo());
            st.setInt(12, c.getId());
            
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(NumberFormatException | SQLException e){
            System.out.println("No se puede eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public PersonaDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        PersonaDTO per = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                per= new PersonaDTO();
                per.setId(rs.getInt(1));
                per.setNombre(rs.getString(2));
                per.setApellido(rs.getString(3));
                per.setTipo(rs.getString(4));
                per.setTipoDoc(rs.getString(5));
                per.setNumDoc(rs.getInt(6));
                per.setSexo(rs.getString(7));
                per.setFechNac(rs.getDate(8));
                per.setDireccion(rs.getString(9));
                per.setTelefono(rs.getString(10));
                per.setEmail(rs.getString(11));
                per.setEstado(rs.getBoolean(12));
                
                

            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return per;
    }
    
    @Override
    public List<PersonaDTO> readAll() throws Exception {
      
        ArrayList<PersonaDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                PersonaDTO per = new PersonaDTO();
                per.setId(rs.getInt(1));
                per.setNombre(rs.getString(2));
                per.setApellido(rs.getString(3));
                per.setTipo(rs.getString(4));
                per.setTipoDoc(rs.getString(5));
                per.setNumDoc(rs.getInt(6));
                per.setSexo(rs.getString(7));
                per.setFechNac(rs.getDate(8));
                per.setDireccion(rs.getString(9));
                per.setTelefono(rs.getString(10));
                per.setEmail(rs.getString(11));
                per.setEstado(rs.getBoolean(12));

                lista.add(per);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
     public List<Object[]> buscar(String palabra,boolean verInactivos,String tipo) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("SELECT * FROM persona WHERE nombre_per like concat('%',?,'%') AND tipo_per = ?");
            st.setString(1, palabra);
            st.setString(2, tipo);  
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM persona WHERE nombre_per like concat('%',?,'%') AND  estado_per = ? AND tipo_per = ?");
            st.setString(1, palabra);
            st.setBoolean(2, true);
            st.setString(3, tipo);  
            }
           
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] per = new Object[12];
                per[0] = rs.getInt(1);
                per[1]=rs.getString(2);
                per[2]=rs.getString(3);
                per[3]=rs.getString(4);
                per[4]=rs.getString(5);
                per[5]=rs.getObject(6);
                per[6]=rs.getString(7);
                per[7]=rs.getDate(8);
                per[8]=rs.getString(9);
                per[9]=rs.getString(10);
                per[10]=rs.getString(11);
                per[11]=rs.getBoolean(12);    
                
                
                lista.add(per);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> buscarDni(int palabra,boolean verInactivos,String tipo) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            if(verInactivos){
            st = con.getConexion().prepareStatement("SELECT * FROM persona WHERE num_doc_per = ? AND tipo_per = ? ");
            st.setInt(1, palabra);
            st.setString(2, tipo); 
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM persona WHERE num_doc_per = ? AND  estado_per = ? AND tipo_per = ? ");
            st.setInt(1, palabra);
            st.setBoolean(2, true);
            st.setString(3, tipo); 
            }
            
            
            
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] per = new Object[12];
                per[0] = rs.getInt(1);
                per[1]=rs.getString(2);
                per[2]=rs.getString(3);
                per[3]=rs.getString(4);
                per[4]=rs.getString(5);
                per[5]=rs.getObject(6);
                per[6]=rs.getString(7);
                per[7]=rs.getDate(8);
                per[8]=rs.getString(9);
                per[9]=rs.getString(10);
                per[10]=rs.getString(11);
                per[11]=rs.getBoolean(12);
                
                lista.add(per);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> SinFiltros(boolean verInactivos,String tipo) throws Exception {
      
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{   
            if(verInactivos){
            st = con.getConexion().prepareStatement("select * from persona WHERE tipo_per = ?");
            st.setString(1, tipo); 
            }else{
            st = con.getConexion().prepareStatement("SELECT * FROM persona WHERE estado_per = ? AND tipo_per = ?");
            st.setBoolean(1, true);
            st.setString(2, tipo); 
            }
            

            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] per = new Object[12];
               per[0] = rs.getInt(1);
                per[1]=rs.getString(2);
                per[2]=rs.getString(3);
                per[3]=rs.getString(4);
                per[4]=rs.getString(5);
                
                per[5]=rs.getObject(6);
                
                
                per[6]=rs.getString(7);
                per[7]=rs.getDate(8);
                per[8]=rs.getString(9);
                per[9]=rs.getString(10);
                per[10]=rs.getString(11);
                per[11]=rs.getBoolean(12); 

                lista.add(per);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
}
