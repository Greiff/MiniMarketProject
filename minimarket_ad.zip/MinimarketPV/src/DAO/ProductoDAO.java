/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.ProductoDTO;
import Dato.VentaDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class ProductoDAO implements DAOgeneral<ProductoDTO>{
    
    private static final String SQL_INSERT="INSERT INTO producto(nombre_prod,cod_barra_prod,precio_prod,imagen_prod,estado_prod,detalle_prod,id_categ) VALUES(?,?,?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM producto WHERE id_prod = ? ";
    private static final String SQL_UPDATE="UPDATE producto SET nombre_prod = ?,cod_barra_prod= ?,precio_prod =?,imagen_prod=?,estado_prod=?,detalle_prod=?,id_categ=? WHERE id_prod = ?";
    private static final String SQL_READ="SELECT * FROM producto WHERE id_prod = ?";
    private static final String SQL_READALL="SELECT * FROM producto";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean create(ProductoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setString(2, c.getCodBarra());
            st.setBigDecimal(3, c.getPrecio());
            st.setObject(4, c.getImagen());
            st.setBoolean(5, c.getEstado());
            st.setString(6, c.getDetalle());
            st.setInt(7, c.getIdCateg());

            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(ProductoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setString(2, c.getCodBarra());
            st.setBigDecimal(3, c.getPrecio());
            st.setObject(4, c.getImagen());
            st.setBoolean(5, c.getEstado());
            st.setString(6, c.getDetalle());
            st.setInt(7, c.getIdCateg());
            st.setInt(8, c.getId());

            if(st.executeUpdate()>0){
                System.out.println("se actualizo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            System.out.println("No se puede eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public ProductoDTO read(Object key) throws Exception {
        PreparedStatement st;
        ResultSet rs;
        ProductoDTO prod = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                prod= new ProductoDTO();
                prod.setId(rs.getInt(1));
                prod.setNombre(rs.getString(2));
                prod.setCodBarra(rs.getString(3));
                prod.setPrecio(rs.getBigDecimal(4));
                prod.setImagen(rs.getString(5));
                prod.setEstado(rs.getBoolean(6));
                prod.setDetalle(rs.getString(7));
                prod.setIdCateg(rs.getInt(8));
       
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return prod;
    }

    @Override
    public List readAll() throws Exception {
        ArrayList<ProductoDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                ProductoDTO prod= new ProductoDTO();
                prod.setId(rs.getInt(1));
                prod.setNombre(rs.getString(2));
                prod.setCodBarra(rs.getString(3));
                prod.setPrecio(rs.getBigDecimal(4));
                prod.setImagen(rs.getString(5));
                prod.setEstado(rs.getBoolean(6));
                prod.setDetalle(rs.getString(7));
                prod.setIdCateg(rs.getInt(8));
                lista.add(prod);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    
    
}
