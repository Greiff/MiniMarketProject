/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.*;
import Dato.*;
import Interfaz.*;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Sistema
 */
public class RolDAO implements DAOgeneral<RolDTO>{

    private static final String SQL_INSERT="INSERT INTO rol(nombre_rol,reg_venta_rol,reg_ing_rol,reg_prod_rol, reg_prov_rol,reg_cli_rol,reg_cat_rol,reg_lote_rol,reg_rol_rol,anular_venta_rol,anular_ing_rol,info_venta_rol,info_ingreso_rol,respaldarBD_rol,restaurarBD_rol,info_caja_rol) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
    private static final String SQL_DELETE="DELETE FROM rol WHERE id_rol = ? ";
    private static final String SQL_UPDATE="UPDATE rol SET nombre_rol= ?, reg_venta_rol=?,reg_ing_rol=?,reg_prod_rol=?, reg_prov_rol=?,reg_cli_rol=?,reg_cat_rol=?,reg_lote_rol=?,reg_rol_rol=?,anular_venta_rol=?,anular_ing_rol=?,info_venta_rol=?,info_ingreso_rol=?,respaldarBD_rol=?,restaurarBD_rol=?,info_caja_rol=? WHERE id_rol = ?";
    private static final String SQL_READ="SELECT * FROM rol WHERE id_rol = ?";
    private static final String SQL_READALL="SELECT * FROM rol";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(RolDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setBoolean(2, c.isRegVenta());
            st.setBoolean(3, c.isRegIng());
            st.setBoolean(4, c.isRegProd());
            st.setBoolean(5, c.isRegProv());
            st.setBoolean(6, c.isRegCli());
            st.setBoolean(7, c.isRegCat());
            st.setBoolean(8, c.isRegLote());
            st.setBoolean(9, c.isRegRol());
            st.setBoolean(10, c.isAnularVenta());
            st.setBoolean(11, c.isAnularIng());
            st.setBoolean(12, c.isInfoVenta());
            st.setBoolean(13, c.isInfoIngreso());
            st.setBoolean(14, c.isRespaldarBD());
            st.setBoolean(15, c.isRestaurarBD());
            st.setBoolean(16, c.isInfoCaja());
         
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(RolDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            st.setString(1, c.getNombre());
            st.setBoolean(2, c.isRegVenta());
            st.setBoolean(3, c.isRegIng());
            st.setBoolean(4, c.isRegProd());
            st.setBoolean(5, c.isRegProv());
            st.setBoolean(6, c.isRegCli());
            st.setBoolean(7, c.isRegCat());
            st.setBoolean(8, c.isRegLote());
            st.setBoolean(9, c.isRegRol());
            st.setBoolean(10, c.isAnularVenta());
            st.setBoolean(11, c.isAnularIng());
            st.setBoolean(12, c.isInfoVenta());
            st.setBoolean(13, c.isInfoIngreso());
            st.setBoolean(14, c.isRespaldarBD());
            st.setBoolean(15, c.isRestaurarBD());
            st.setBoolean(16, c.isInfoCaja());
            st.setInt(17, c.getId());
            
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key){
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(NumberFormatException | SQLException e){
            System.out.println("No se pude eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public RolDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        RolDTO r = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                r = new RolDTO();
                
                 r.setId(rs.getInt(1));
                r.setNombre(rs.getString(2));
                r.setRegVenta(rs.getBoolean(3));
                r.setRegIng(rs.getBoolean(4));
                r.setRegProd(rs.getBoolean(5));
                r.setRegProv(rs.getBoolean(6));
                r.setRegCli(rs.getBoolean(7));
                r.setRegCat(rs.getBoolean(8));
                r.setRegLote(rs.getBoolean(9));
                r.setRegRol(rs.getBoolean(10));
                r.setAnularVenta(rs.getBoolean(11));
                r.setAnularIng(rs.getBoolean(12));
                r.setInfoVenta(rs.getBoolean(13));
                r.setInfoIngreso(rs.getBoolean(14));
                r.setRespaldarBD(rs.getBoolean(15));
                r.setRestaurarBD(rs.getBoolean(16));
                r.setInfoCaja(rs.getBoolean(17));
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return r;
    }
    
    @Override
    public List<RolDTO> readAll() throws Exception {
      
        ArrayList<RolDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                RolDTO r= new RolDTO();
                
                r.setId(rs.getInt(1));
                r.setNombre(rs.getString(2));
                r.setRegVenta(rs.getBoolean(3));
                r.setRegIng(rs.getBoolean(4));
                r.setRegProd(rs.getBoolean(5));
                r.setRegProv(rs.getBoolean(6));
                r.setRegCli(rs.getBoolean(7));
                r.setRegCat(rs.getBoolean(8));
                r.setRegLote(rs.getBoolean(9));
                r.setRegRol(rs.getBoolean(10));
                r.setAnularVenta(rs.getBoolean(11));
                r.setAnularIng(rs.getBoolean(12));
                r.setInfoVenta(rs.getBoolean(13));
                r.setInfoIngreso(rs.getBoolean(14));
                r.setRespaldarBD(rs.getBoolean(15));
                r.setRestaurarBD(rs.getBoolean(16));
                r.setInfoCaja(rs.getBoolean(17));
                
                lista.add(r);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    public List<Object[]> buscar(String palabra) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            st = con.getConexion().prepareStatement("call BuscarPorNombreRol(?)");
            st.setString(1, palabra);
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[17];
                rol[0] = rs.getInt(1);
                rol[1]=rs.getString(2);
                rol[2]=rs.getBoolean(3);
                rol[3]=rs.getBoolean(4);
                rol[4]=rs.getBoolean(5);
                rol[5]=rs.getBoolean(6);
                rol[6]=rs.getBoolean(7);
                rol[7]=rs.getBoolean(8);
                rol[8]=rs.getBoolean(9);
                rol[9]=rs.getBoolean(10);
                rol[10]=rs.getBoolean(11);
                rol[11]=rs.getBoolean(12);  
                rol[12]=rs.getBoolean(13);
                rol[13]=rs.getBoolean(14);
                rol[14]=rs.getBoolean(15);
                rol[15]=rs.getBoolean(16);
                rol[16]=rs.getBoolean(17);
   
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> buscarID(int palabra) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            st = con.getConexion().prepareStatement("call BuscarPorIDRol(?)");
            st.setInt(1, palabra);
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[17];
                rol[0] = rs.getInt(1);
                rol[1]=rs.getString(2);
                rol[2]=rs.getBoolean(3);
                rol[3]=rs.getBoolean(4);
                rol[4]=rs.getBoolean(5);
                rol[5]=rs.getBoolean(6);
                rol[6]=rs.getBoolean(7);
                rol[7]=rs.getBoolean(8);
                rol[8]=rs.getBoolean(9);
                rol[9]=rs.getBoolean(10);
                rol[10]=rs.getBoolean(11);
                rol[11]=rs.getBoolean(12);  
                rol[12]=rs.getBoolean(13);
                rol[13]=rs.getBoolean(14);
                rol[14]=rs.getBoolean(15);
                rol[15]=rs.getBoolean(16);
                rol[16]=rs.getBoolean(17);
    
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> SinFiltros() throws Exception {
      
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement("select * from rol");
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] rol = new Object[17];
                rol[0] = rs.getInt(1);
                rol[1]=rs.getString(2);
                rol[2]=rs.getBoolean(3);
                rol[3]=rs.getBoolean(4);
                rol[4]=rs.getBoolean(5);
                rol[5]=rs.getBoolean(6);
                rol[6]=rs.getBoolean(7);
                rol[7]=rs.getBoolean(8);
                rol[8]=rs.getBoolean(9);
                rol[9]=rs.getBoolean(10);
                rol[10]=rs.getBoolean(11);
                rol[11]=rs.getBoolean(12);  
                rol[12]=rs.getBoolean(13);
                rol[13]=rs.getBoolean(14);
                rol[14]=rs.getBoolean(15);
                rol[15]=rs.getBoolean(16);
                rol[16]=rs.getBoolean(17);
        
                
                
                lista.add(rol);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    
}
