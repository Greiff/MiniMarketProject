/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.Detalle_IngresoDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class Detalle_IngresoDAO implements DAOgeneral<Detalle_IngresoDTO> {
    private static final String SQL_INSERT="INSERT INTO detalle_venta(cantidad_deting,precio_deting,id_prod,id_ingreso,id_stock) VALUES(?,?,?,?,?)";
    private static final String SQL_DELETE="DELETE FROM detalle_venta WHERE id_det_venta = ? ";
    private static final String SQL_UPDATE="UPDATE detalle_venta SET cantidad_deting=?,precio_deting=?,id_prod=?,id_ingreso=?,id_stock=? WHERE id_det_venta = ?";
    private static final String SQL_READ="SELECT * FROM detalle_venta WHERE id_det_venta = ?";
    private static final String SQL_READALL="SELECT * FROM detalle_venta";
    
    private static final Conexion CON = Conexion.saberEstado();

    @Override
    public boolean create(Detalle_IngresoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = CON.getConexion().prepareStatement(SQL_INSERT);
            st.setInt(1, c.getCantidad());
            st.setBigDecimal(2, c.getPrecio());
            st.setInt(3, c.getIdProd());
            st.setInt(4, c.getIdIngreso());
            st.setInt(5, c.getIdStock());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            CON.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(Detalle_IngresoDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = CON.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setInt(1, c.getCantidad());
            st.setBigDecimal(2, c.getPrecio());
            st.setInt(3, c.getIdProd());
            st.setInt(4, c.getIdIngreso());
            st.setInt(5, c.getIdStock());
             
            st.setInt(6, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(SQLException e){
            throw e;
        }finally{
            CON.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) throws Exception {
        PreparedStatement st;
        try{ 
            st = CON.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(NumberFormatException | SQLException e){
            throw e;
        }finally{
            CON.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public Detalle_IngresoDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        Detalle_IngresoDTO dv = null;
        
        try{
            st = CON.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                dv = new Detalle_IngresoDTO();
                dv.setId(rs.getInt(1));
                dv.setCantidad(rs.getInt(2));
                dv.setPrecio(rs.getBigDecimal(3));
                dv.setIdProd(rs.getInt(4));
                dv.setIdIngreso(rs.getInt(5));
                dv.setIdStock(rs.getInt(6));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            CON.cerrarConexion();
        }
        return dv;
    }
    
    @Override
    public List<Detalle_IngresoDTO> readAll() throws Exception {
      
        ArrayList<Detalle_IngresoDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = CON.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                Detalle_IngresoDTO dv = new Detalle_IngresoDTO();
                dv.setId(rs.getInt(1));
                dv.setCantidad(rs.getInt(2));
                dv.setPrecio(rs.getBigDecimal(3));
                dv.setIdProd(rs.getInt(4));
                dv.setIdIngreso(rs.getInt(5));
                dv.setIdStock(rs.getInt(6));
                
                lista.add(dv);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            CON.cerrarConexion();
        }
        return lista;
    }
}
