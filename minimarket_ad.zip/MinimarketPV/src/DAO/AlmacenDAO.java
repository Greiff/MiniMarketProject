/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Dato.AlmacenDTO;
import Interfaz.DAOgeneral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class AlmacenDAO implements DAOgeneral<AlmacenDTO>{
    private static final String SQL_INSERT="INSERT INTO almacen(nombre_alma,direccion_alma,telefono_alma) VALUES(?,?,?)";
    private static final String SQL_DELETE="DELETE FROM almacen WHERE id_alma = ?";
    private static final String SQL_UPDATE="UPDATE almacen SET nombre_alma=?,direccion_alma=?,telefono_alma=? WHERE id_alma = ?";
    private static final String SQL_READ="SELECT * FROM almacen WHERE id_alma = ?";
    private static final String SQL_READALL="SELECT * FROM almacen";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean create(AlmacenDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_INSERT);
            st.setString(1, c.getNombre());
            st.setString(2, c.getDireccion());
            st.setString(3, c.getTelefono());

            
            if(st.executeUpdate()>0){
                System.out.println("se creo"); 
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean update(AlmacenDTO c) throws Exception {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_UPDATE);
            
            st.setString(1, c.getNombre());
            st.setString(2, c.getDireccion());
            st.setString(3, c.getTelefono());

            
            st.setInt(4, c.getId());
                    
            if(st.executeUpdate()>0){
                System.out.println("se actualizo");   
                return true;
            }
        }catch(Exception e){
            throw e;
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean delete(Object key) {
        PreparedStatement st;
        try{ 
            st = con.getConexion().prepareStatement(SQL_DELETE);
            st.setInt(1,Integer.valueOf(key.toString()));
            if(st.executeUpdate()>0){
                System.out.println("se elimino");   
                return true;
            }
        }catch(Exception e){
            System.out.println("No se puede eliminar");
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    
    @Override
    public AlmacenDTO read(Object key) throws Exception {
   
        PreparedStatement st;
        ResultSet rs;
        AlmacenDTO alma = null;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READ);
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();
            
            while (rs.next()){
                alma = new AlmacenDTO();
                alma.setId(rs.getInt(1));
                alma.setNombre(rs.getString(2));
                alma.setDireccion(rs.getString(3));
                alma.setTelefono(rs.getString(4));
      
            }
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return alma;
    }
    
    @Override
    public List<AlmacenDTO> readAll() throws Exception {
      
        ArrayList<AlmacenDTO> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement(SQL_READALL);
            rs = st.executeQuery();
            
            while (rs.next()){
                AlmacenDTO alma = new AlmacenDTO();
                alma.setId(rs.getInt(1));
                alma.setNombre(rs.getString(2));
                alma.setDireccion(rs.getString(3));
                alma.setTelefono(rs.getString(4));
                
                lista.add(alma);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
    
    public List<Object[]> buscar(String palabra) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            st = con.getConexion().prepareStatement("SELECT * FROM Almacen WHERE nombre_alma like concat('%',?,'%')");
            st.setString(1, palabra);
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] alma = new Object[4];
                alma[0] = rs.getInt(1);
                alma[1]=rs.getString(2);
                alma[2]=rs.getString(3);
                alma[3]=rs.getString(4);
               
                lista.add(alma);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> buscarID(int palabra) throws SQLException{
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
         try{
            st = con.getConexion().prepareStatement("SELECT * FROM Almacen WHERE id_alma =?");
            st.setInt(1, palabra);
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] alma = new Object[4];
                alma[0] = rs.getInt(1);
                alma[1]=rs.getString(2);
                alma[2]=rs.getString(3);
                alma[3]=rs.getString(4);
               
                lista.add(alma);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    
    }
    
    public List<Object[]> SinFiltros() throws Exception {
      
        ArrayList<Object[]> lista= new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            st = con.getConexion().prepareStatement("select * from almacen");
            rs = st.executeQuery();
            
            while (rs.next()){
                Object[] alma = new Object[4];
                alma[0] = rs.getInt(1);
                alma[1]=rs.getString(2);
                alma[2]=rs.getString(3);
                alma[3]=rs.getString(4);
               
                lista.add(alma);
            }
            
        }catch(SQLException e){
            throw e;
        } finally{
            con.cerrarConexion();
        }
        return lista;
    }
}
