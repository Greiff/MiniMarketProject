/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class Conexion {
    private Connection conexion;
    public static Conexion instancia;
    private final String DRIVER = "com.mysql.jdbc.Driver";
    private final String USER ="root";
    private final String PASS="";
    private final String URL= "jdbc:mysql://localhost:3306/minimarket_v2";
    
    private Conexion(){
        try {
            Class.forName(DRIVER);
             conexion=DriverManager.getConnection(URL,USER,PASS);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    public synchronized static Conexion saberEstado(){
        if(instancia ==  null){
            instancia = new Conexion();
        }
        return instancia;
    }

    public Connection getConexion() {
        return conexion;
    }
    
    
    public void cerrarConexion(){
        instancia=null;
    }
 
}
