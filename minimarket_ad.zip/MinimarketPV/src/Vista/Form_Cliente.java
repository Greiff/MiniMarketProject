/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Dato.PersonaDTO;
import Negocio.ClsPersona;
import java.sql.Date;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sistema
 */
public class Form_Cliente extends javax.swing.JFrame {

    /**
     * Creates new form form_rol
     */
    
    DefaultTableModel modelo;
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    private int CodCliMod;
    private final static String TIPO = "CLIENTE";
    
    public Form_Cliente() {
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        jTabbedPane2.setEnabledAt(1,false);
        
        modelo= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        // declarar cabecera
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDO");
        modelo.addColumn("TIPO");
        modelo.addColumn("DOC");
        modelo.addColumn("DNI");
        modelo.addColumn("SEXO");
        modelo.addColumn("FECHA NAC");
        
        modelo.addColumn("DIRECCION");       
        modelo.addColumn("TELEFONO");
        modelo.addColumn("EMAIL");
        
        modelo.addColumn("ESTADO");


      
             
        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.jTable1.setModel(modelo);
        
        this.OcultarColumnas(0);
        this.OcultarColumnas(3);
        this.OcultarColumnas(4);
        
       
        
        // se acrtiva mostar por primera vez
        try {
            this.mostrar();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.HabilitarBotones();
   
    }
    
    
     //limpia los cuadros de texto
    private void Limpiar(){
         this.textNombre.setText("");
         this.textApellido.setText("");
         this.textDNI.setText("");
         this.textEmail.setText("");
         this.textID.setText("");
         this.textTelf.setText("");
         this.dateNac.setText("");
         this.textDireccion.setText("");

     }
     // habilita botones dependido del estado de variables nuevo y modificar
     private void HabilitarBotones(){
         if(this.Nuevo || this.Modificar){
             this.btnNuevo.setEnabled(false);
             this.btnModificar.setEnabled(false);
             this.btnEliminar.setEnabled(false);
             this.btnGuardar.setEnabled(true);
             this.btnCancelar.setEnabled(true);
             this.btnSalir.setEnabled(false);
             
         } else{
             this.btnNuevo.setEnabled(true);
             this.btnModificar.setEnabled(false);
             this.btnEliminar.setEnabled(false);
             this.btnGuardar.setEnabled(false);
             this.btnCancelar.setEnabled(false);
             this.btnSalir.setEnabled(true);
         }
             
     }
     
     public boolean esNumero(String cadena) {

        boolean resultado;

        try {
            Integer.parseInt(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }
        return resultado;
    }
     
     
     //reduce lasdimenxsiones deun columna para aparentar que no existe
    private void OcultarColumnas(int a){
            jTable1.getColumnModel().getColumn(a).setMaxWidth(0);
            jTable1.getColumnModel().getColumn(a).setMinWidth(0);
            jTable1.getColumnModel().getColumn(a).setPreferredWidth(0);
    }
     
    // funcion para imprimir la tabla
     private void mostrar() throws Exception{
          ClsPersona clase = new ClsPersona();
          for(int i=0;i<clase.MostrarSinFiltro(jCheckVerInactivos.isSelected(),TIPO).size();i++)
          modelo.addRow(clase.MostrarSinFiltro(jCheckVerInactivos.isSelected(),TIPO).get(i));
    }
     
     // funcion para ctualizar tabla 
      private void actualizarTabla() throws Exception{
          modelo.setRowCount(0);
          mostrar();
          
      }
     
     private void Buscar(){
         ClsPersona clase = new ClsPersona();
         modelo.setRowCount(0);
         
         
          if(nombreBuscar.isSelected() == true){
          String palabra = jTextField1.getText();
          for(int i=0;i<clase.buscar(palabra,jCheckVerInactivos.isSelected(),TIPO).size();i++)
          modelo.addRow(clase.buscar(palabra,jCheckVerInactivos.isSelected(),TIPO).get(i));
          
          
         }else{
          int palabra = Integer.valueOf(jTextField1.getText());
          for(int i=0;i<clase.buscarDni(palabra,jCheckVerInactivos.isSelected(),TIPO).size();i++)
          modelo.addRow(clase.buscarDni(palabra,jCheckVerInactivos.isSelected(),TIPO).get(i));   
         }    
     }
     
     private boolean guardarNuevo(){
         ClsPersona clase = new ClsPersona();
         PersonaDTO cliente = new PersonaDTO();
         boolean dni =true;
         
         if(textNombre.getText().equalsIgnoreCase("")){
             JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Ventas",0);
         }
         else{
            
            if(esNumero(textDNI.getText())|| textDNI.getText().equalsIgnoreCase("")){
            
            cliente.setNombre(textNombre.getText());
            cliente.setApellido(textApellido.getText());
            cliente.setEmail(textEmail.getText());
           
            if(dateNac.getDate()==null) cliente.setFechNac(null);
            else cliente.setFechNac(Date.valueOf(dateNac.getDate()));
            
            cliente.setDireccion(textDireccion.getText());
            cliente.setTelefono(textTelf.getText());
            cliente.setTipo(TIPO);
            
            if(textDNI.getText().equalsIgnoreCase("")) cliente.setNumDoc(0);
                else cliente.setNumDoc(Integer.valueOf(textDNI.getText()));
            
            cliente.setTipoDoc("DNI");

            if(radioActivo.isSelected()==true) cliente.setEstado(true);
            else cliente.setEstado(false);

            if(radioMasculino.isSelected()==true) cliente.setSexo("M");
                else cliente.setSexo("F");
            
            
            clase.GuardarNuevo(cliente);

            this.Limpiar();
            
            JOptionPane.showMessageDialog(this, "Cliente Creado.","Sistema de Ventas",1);    
            return true;
            } 
            else {
                JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                return false;
            } 
         }
        return false;         
     }
     
     private void inhabilitarUsuario(){
        
        ClsPersona clase = new ClsPersona();
        PersonaDTO cliente = new PersonaDTO();

        cliente = clase.recuperarPersona(CodCliMod); //se recrea el objeto usuario con sus atributos
        cliente.setEstado(false);
        
        clase.GuardarModificado(cliente);
        JOptionPane.showMessageDialog(this, "Usuario inhabilitado.","Sistema de Ventas",1);
     }
     
     private boolean guardarModificado(){
         ClsPersona clase = new ClsPersona();
         PersonaDTO cliente = new PersonaDTO();
         boolean dni =true;
         
         if(textNombre.getText().equalsIgnoreCase("")){
             JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Ventas",0);
         }
         else{
                if(esNumero(textDNI.getText())|| textDNI.getText().equalsIgnoreCase("")||textDNI.getText()==null){
                cliente.setId(CodCliMod);
                cliente.setNombre(textNombre.getText());
                cliente.setApellido(textApellido.getText());
                cliente.setEmail(textEmail.getText());
                if(dateNac.getDate()==null) cliente.setFechNac(null);
                else cliente.setFechNac(Date.valueOf(dateNac.getDate()));
                cliente.setDireccion(textDireccion.getText());
                cliente.setTelefono(textTelf.getText());
                
                if(textDNI.getText().equalsIgnoreCase("")) cliente.setNumDoc(0);
                else cliente.setNumDoc(Integer.valueOf(textDNI.getText()));
                
                
                cliente.setTipoDoc("DNI");
                cliente.setTipo(TIPO);
                
                if(radioActivo.isSelected()==true) cliente.setEstado(true);
                else cliente.setEstado(false);
                
                if(radioMasculino.isSelected()==true) cliente.setSexo("M");
                else cliente.setSexo("F");

                clase.GuardarModificado(cliente);
                
                
                JOptionPane.showMessageDialog(this, "Cliente Modificado.","Sistema de Ventas",1);
                return true;
                 }
                else{
                    JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                    return false;
                }
         }
        return false;     
     }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        nombreBuscar = new javax.swing.JRadioButton();
        jTextField1 = new javax.swing.JTextField();
        DNICliente = new javax.swing.JRadioButton();
        btnBuscar = new javax.swing.JButton();
        jCheckVerInactivos = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textID = new javax.swing.JTextField();
        textApellido = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textDNI = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        textEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        textTelf = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textDireccion = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        radioActivo = new javax.swing.JRadioButton();
        radioInactivo = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        radioMasculino = new javax.swing.JRadioButton();
        radioFemenino = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        dateNac = new com.github.lgooddatepicker.components.DatePicker();
        jPanel4 = new javax.swing.JPanel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cliente");

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(nombreBuscar);
        nombreBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nombreBuscar.setSelected(true);
        nombreBuscar.setText("Nombre Cliente");
        nombreBuscar.setName(""); // NOI18N
        nombreBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreBuscarActionPerformed(evt);
            }
        });

        Grupo_Rol.add(DNICliente);
        DNICliente.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        DNICliente.setText("DNI Cliente");

        btnBuscar.setText("Buscar");
        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jCheckVerInactivos.setText("Ver inactivos");
        jCheckVerInactivos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jCheckVerInactivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckVerInactivosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(nombreBuscar)
                        .addGap(18, 18, 18)
                        .addComponent(DNICliente)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckVerInactivos)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nombreBuscar)
                    .addComponent(DNICliente)
                    .addComponent(jCheckVerInactivos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        nombreBuscar.getAccessibleContext().setAccessibleDescription("");

        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTable1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Ciente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        textNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNombreActionPerformed(evt);
            }
        });

        jLabel1.setText("*Nombre:");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel2.setText("ID Cliente:");
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textID.setEnabled(false);
        textID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIDActionPerformed(evt);
            }
        });

        textApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textApellidoActionPerformed(evt);
            }
        });

        jLabel3.setText("Apellidos:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDNIActionPerformed(evt);
            }
        });

        jLabel4.setText("DNI:");
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textEmailActionPerformed(evt);
            }
        });

        jLabel5.setText("E-mail:");
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textTelf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textTelfActionPerformed(evt);
            }
        });

        jLabel8.setText("Teléfono:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDireccion.setColumns(20);
        textDireccion.setRows(5);
        jScrollPane1.setViewportView(textDireccion);

        jLabel9.setText("Dirección:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Estado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        buttonGroup2.add(radioActivo);
        radioActivo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        radioActivo.setSelected(true);
        radioActivo.setText("Activo");
        radioActivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioActivoActionPerformed(evt);
            }
        });

        buttonGroup2.add(radioInactivo);
        radioInactivo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        radioInactivo.setText("Inactivo");
        radioInactivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioInactivoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(radioActivo)
                .addGap(18, 18, 18)
                .addComponent(radioInactivo)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioActivo)
                    .addComponent(radioInactivo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setText("Sexo:");
        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        buttonGroup1.add(radioMasculino);
        radioMasculino.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        radioMasculino.setSelected(true);
        radioMasculino.setText("Masculino");
        radioMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioMasculinoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioFemenino);
        radioFemenino.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        radioFemenino.setText("Femenino");
        radioFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioFemeninoActionPerformed(evt);
            }
        });

        jLabel13.setText("Fech Nac:");
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textApellido)
                                    .addComponent(textNombre)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textID, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(textEmail, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(dateNac, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textTelf)))))
                            .addComponent(jScrollPane1)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(radioMasculino)
                        .addGap(18, 18, 18)
                        .addComponent(radioFemenino)))
                .addGap(36, 36, 36))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(textID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addComponent(dateNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5)
                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel8)
                    .addComponent(textTelf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(radioMasculino)
                            .addComponent(radioFemenino)
                            .addComponent(jLabel12))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(15, 15, 15))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Nuevo / Modificar", jPanel2);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Acciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        btnNuevo.setText("Nuevo");
        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btnNuevo)
                .addGap(35, 35, 35)
                .addComponent(btnGuardar)
                .addGap(34, 34, 34)
                .addComponent(btnModificar)
                .addGap(26, 26, 26)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(54, 54, 54))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
       Modificar = true; //declaro amodificar activado
        jTabbedPane2.setSelectedIndex(1); // se carga la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
  
        HabilitarBotones(); // se vuelve a habilitar los botones
        
        ClsPersona clase = new ClsPersona();
        PersonaDTO cliente = new PersonaDTO();

        cliente= clase.recuperarPersona(CodCliMod); //se recrea el objeto usuario con sus atributos
        

        // se llena las cajas de texto
        
        this.textNombre.setText(cliente.getNombre());
        this.textApellido.setText(cliente.getApellido());
            
        if(cliente.getNumDoc()==0) this.textDNI.setText("");
        else this.textDNI.setText(String.valueOf(cliente.getNumDoc())); 
        
        this.textEmail.setText(cliente.getEmail());
        
        this.textTelf.setText(cliente.getTelefono());
        
        if(cliente.getEstado()) radioActivo.setSelected(true);
        else radioInactivo.setSelected(true);
        
    
        if(cliente.getSexo().equalsIgnoreCase("M")) radioMasculino.setSelected(true);
        else radioFemenino.setSelected(true);
        
        
        if(cliente.getFechNac()==null){
            this.dateNac.setDate(null);
        }   
        else{
            Date date = cliente.getFechNac();
            LocalDate fechNac = date.toLocalDate();
            this.dateNac.setDate(fechNac);
        }
        this.textDireccion.setText(cliente.getDireccion());
        
        this.textID.setText(String.valueOf(cliente.getId()));

       
    }//GEN-LAST:event_btnModificarActionPerformed

    private void nombreBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreBuscarActionPerformed

    private void radioFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioFemeninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioFemeninoActionPerformed

    private void radioMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioMasculinoActionPerformed

    private void radioInactivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioInactivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioInactivoActionPerformed

    private void radioActivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioActivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioActivoActionPerformed

    private void textTelfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textTelfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textTelfActionPerformed

    private void textEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textEmailActionPerformed

    private void textDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDNIActionPerformed

    private void textApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textApellidoActionPerformed

    private void textIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIDActionPerformed

    private void textNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNombreActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(nombreBuscar.isSelected()){
            this.Buscar(); 
        }
        else if(DNICliente.isSelected()&&esNumero(jTextField1.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void jCheckVerInactivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckVerInactivosActionPerformed
        if(nombreBuscar.isSelected()){
            this.Buscar();
        }
        else if(DNICliente.isSelected()&&esNumero(jTextField1.getText())){
            this.Buscar();
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_jCheckVerInactivosActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        boolean verificar;
        if(Modificar) verificar = guardarModificado();//se pone modificar para evitar problemas con nuevo
        else verificar = guardarNuevo();
        
        if(verificar){
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0);
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones 
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo = true; // se activa el nuevo
        jTabbedPane2.setSelectedIndex(1); // se redirecciona a la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones();       
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
         ClsPersona clase = new ClsPersona();
        int resp = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este Cliente?", "Sistema de Ventas", 0,2);
        int resp2;  
        if(resp==0){
             if(!clase.Eliminar(CodCliMod)){
                 resp2 = JOptionPane.showConfirmDialog(this,"No se puede eliminar el Cliente por riesgo de perdida de infomación. ¿Desea inhabilitarlo?", "Sistema de Ventas",0,2);
                 if(resp2==0){
                    inhabilitarUsuario();
                 }    
             }      
             try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
             }
             HabilitarBotones();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        CodCliMod = Integer.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
        this.btnModificar.setEnabled(true);
        this.btnEliminar.setEnabled(true);// una vez seleccionado se habilita la tecla modificar
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
       Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0); // lleva a la pestaña 1
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        HabilitarBotones(); //se refresca la activacion de botones
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton DNICliente;
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private com.github.lgooddatepicker.components.DatePicker dateNac;
    private javax.swing.JCheckBox jCheckVerInactivos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JRadioButton nombreBuscar;
    private javax.swing.JRadioButton radioActivo;
    private javax.swing.JRadioButton radioFemenino;
    private javax.swing.JRadioButton radioInactivo;
    private javax.swing.JRadioButton radioMasculino;
    private javax.swing.JTextField textApellido;
    private javax.swing.JTextField textDNI;
    private javax.swing.JTextArea textDireccion;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textID;
    private javax.swing.JTextField textNombre;
    private javax.swing.JTextField textTelf;
    // End of variables declaration//GEN-END:variables

}
