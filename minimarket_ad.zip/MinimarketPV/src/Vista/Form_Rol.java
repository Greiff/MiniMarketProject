/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Dato.RolDTO;
import Negocio.ClsRol;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sistema
 */
public class Form_Rol extends javax.swing.JFrame {

    /**
     * Creates new form form_rol
     */
    DefaultTableModel modelo;
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    private int CodRolMod;
    
    public Form_Rol() {
        
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        jTabbedPane2.setEnabledAt(1, false);
        
        modelo = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) { //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };

        // declarar cabecera
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("R. VENTA");
        modelo.addColumn("R. INGRESO");
        modelo.addColumn("R. PRODUCTO");
        modelo.addColumn("R. PROVEEDOR");
        modelo.addColumn("R. CLIENTE");        
        modelo.addColumn("R. CATEGORIA");
        modelo.addColumn("R. LOTE");
        modelo.addColumn("R. ROL");
        modelo.addColumn("ANULAR VENTA");
        modelo.addColumn("ANULAR INGRESO");
        modelo.addColumn("INFO VENTA");
        modelo.addColumn("INFO INGRESO");
        modelo.addColumn("RESPALDAR BD");
        modelo.addColumn("RESTAURAR BD");
        modelo.addColumn("INFO CAJA");

        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.jTable1.setModel(modelo);
        
        this.OcultarColumnas(0);
        this.OcultarColumnas(4);
        this.OcultarColumnas(12);
        this.OcultarColumnas(13);
        
        try {
            this.mostrar();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        this.HabilitarBotones();
        
    }

    //limpia los cuadros de texto
    private void Limpiar() {
        this.jTextField3.setText("");
        this.textNombre.setText("");
        this.regIng.setSelected(false);
        this.regVenta.setSelected(false);
        this.regProd.setSelected(false);
        this.regProv.setSelected(false);
        this.regCli.setSelected(false);
        this.regCat.setSelected(false);
        this.regRol.setSelected(false);
        this.regAnularVenta.setSelected(false);
        this.regAnularIng.setSelected(false);
        this.regInfoIng.setSelected(false);
        this.regInfoVenta.setSelected(false);
        this.regRespaldarBD.setSelected(false);
        this.regRestaurarBD.setSelected(false);
        this.regInfoCaja.setSelected(false);
        this.regLotes.setSelected(false);
    }

    // habilita botones dependido del estado de variables nuevo y modificar
    private void HabilitarBotones() {
        if (this.Nuevo || this.Modificar) {
            this.btnNuevo.setEnabled(false);
            this.btnModificar.setEnabled(false);
            this.btnEliminar.setEnabled(false);
            this.btnGuardar.setEnabled(true);
            this.btnCancelar.setEnabled(true);
            this.btnSalir.setEnabled(false);
            
        } else {
            this.btnNuevo.setEnabled(true);
            this.btnModificar.setEnabled(false);
            this.btnEliminar.setEnabled(false);
            this.btnGuardar.setEnabled(false);
            this.btnCancelar.setEnabled(false);
            this.btnSalir.setEnabled(true);
        }
        
    }

    //reduce lasdimenxsiones deun columna para aparentar que no existe
    private void OcultarColumnas(int a) {
        jTable1.getColumnModel().getColumn(a).setMaxWidth(0);
        jTable1.getColumnModel().getColumn(a).setMinWidth(0);
        jTable1.getColumnModel().getColumn(a).setPreferredWidth(0);
    }

    // funcion para imprimir la tabla
    private void mostrar() throws Exception {
        ClsRol clase = new ClsRol();
        for (int i = 0; i < clase.MostrarSinFiltro().size(); i++) {
            modelo.addRow(clase.MostrarSinFiltro().get(i));
        }
    }

    // funcion para ctualizar tabla 
    private void actualizarTabla() throws Exception {
        modelo.setRowCount(0);
        mostrar();
        
    }
    
    private void Buscar() {
        ClsRol clase = new ClsRol();
        modelo.setRowCount(0);
        
        if (jRadioButton1.isSelected() == true) {
            String palabra = jTextField1.getText();
            for (int i = 0; i < clase.buscar(palabra).size(); i++) {
                modelo.addRow(clase.buscar(palabra).get(i));
            }
            
        } else {
            int palabra = Integer.valueOf(jTextField1.getText());
            for (int i = 0; i < clase.buscarID(palabra).size(); i++) {
                modelo.addRow(clase.buscarID(palabra).get(i));
            }            
        }        
    }
    
    private boolean guardarNuevo() {
        ClsRol clase = new ClsRol();
        RolDTO rol = new RolDTO();
        
        if (textNombre.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Faltan campos obligatorios", "Sistema de Ventas", 0);
        } else {
            
            rol.setNombre(textNombre.getText());
            
            rol.setRegVenta(regVenta.isSelected());
            rol.setRegIng(regIng.isSelected());
            rol.setRegProd(regProd.isSelected());
            rol.setRegProv(regProv.isSelected());
            rol.setRegCli(regCli.isSelected());
            rol.setRegCat(regCat.isSelected());
            rol.setRegLote(regLotes.isSelected());
            rol.setAnularVenta(regAnularVenta.isSelected());
            rol.setAnularIng(regAnularIng.isSelected());
            rol.setInfoVenta(regInfoVenta.isSelected());
            rol.setInfoIngreso(regInfoIng.isSelected());
            rol.setRespaldarBD(regRespaldarBD.isSelected());
            rol.setRestaurarBD(regRestaurarBD.isSelected());
            rol.setInfoCaja(regInfoCaja.isSelected());
            
            clase.GuardarNuevo(rol);
            
            this.Limpiar();
            
            JOptionPane.showMessageDialog(this, "Usuario Creado.", "Sistema de Ventas", 1);            
            
            return true;            
        }
        return false;        
    }
    
    public boolean esNumero(String cadena) {

        boolean resultado;

        try {
            Integer.parseInt(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }
        return resultado;
    }
    
    private boolean guardarModificado() {
        ClsRol clase = new ClsRol();
        RolDTO rol = new RolDTO();
        
        if (textNombre.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Faltan campos obligatorios", "Sistema de Ventas", 0);
        } else {
            
            rol.setNombre(textNombre.getText());
            rol.setRegVenta(regVenta.isSelected());
            rol.setRegIng(regIng.isSelected());
            rol.setRegProd(regProd.isSelected());
            rol.setRegProv(regProv.isSelected());
            rol.setRegCli(regCli.isSelected());
            rol.setRegCat(regCat.isSelected());
            rol.setRegLote(regLotes.isSelected());
            rol.setAnularVenta(regAnularVenta.isSelected());
            rol.setAnularIng(regAnularIng.isSelected());
            rol.setInfoVenta(regInfoVenta.isSelected());
            rol.setInfoIngreso(regInfoIng.isSelected());
            rol.setRespaldarBD(regRespaldarBD.isSelected());
            rol.setRestaurarBD(regRestaurarBD.isSelected());
            
            rol.setInfoCaja(regInfoCaja.isSelected());
            rol.setId(CodRolMod);
            
            clase.GuardarModificado(rol);
            
            JOptionPane.showMessageDialog(this, "Usuario Modificado.", "Sistema de Ventas", 1);
            return true;
        }
        
        return false;        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jTextField1 = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        regIng = new javax.swing.JCheckBox();
        regVenta = new javax.swing.JCheckBox();
        regProd = new javax.swing.JCheckBox();
        regProv = new javax.swing.JCheckBox();
        regCli = new javax.swing.JCheckBox();
        regCat = new javax.swing.JCheckBox();
        regRol = new javax.swing.JCheckBox();
        regAnularVenta = new javax.swing.JCheckBox();
        regAnularIng = new javax.swing.JCheckBox();
        regInfoVenta = new javax.swing.JCheckBox();
        regInfoIng = new javax.swing.JCheckBox();
        regRespaldarBD = new javax.swing.JCheckBox();
        regRestaurarBD = new javax.swing.JCheckBox();
        regInfoCaja = new javax.swing.JCheckBox();
        regLotes = new javax.swing.JCheckBox();
        jPanel4 = new javax.swing.JPanel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tipo de Usuario");

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioButton1.setSelected(true);
        jRadioButton1.setText("Nombre Tipo Usuario");
        jRadioButton1.setName(""); // NOI18N
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        Grupo_Rol.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioButton2.setText("ID Tipo Usuario");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jRadioButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton2)))
                .addGap(19, 19, 19))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnBuscar)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton1)
                            .addComponent(jRadioButton2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jRadioButton1.getAccessibleContext().setAccessibleDescription("");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTable1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Tipo de Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        textNombre.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        textNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNombreActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("*Nombre:");

        jLabel2.setText("ID Tipo Usuario:");
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jTextField3.setEnabled(false);
        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Permisos del Tipo de Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        regIng.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regIng.setText("Reg. Ingresos");
        regIng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regIngActionPerformed(evt);
            }
        });

        regVenta.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regVenta.setText("Reg. Ventas");
        regVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regVentaActionPerformed(evt);
            }
        });

        regProd.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regProd.setText("Reg. Productos");
        regProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regProdActionPerformed(evt);
            }
        });

        regProv.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regProv.setText("Reg. Proveedores");
        regProv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regProvActionPerformed(evt);
            }
        });

        regCli.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regCli.setText("Reg. Clientes");
        regCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regCliActionPerformed(evt);
            }
        });

        regCat.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regCat.setText("Reg. Categorias");
        regCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regCatActionPerformed(evt);
            }
        });

        regRol.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regRol.setText("Reg. Tipo de Usuario");
        regRol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regRolActionPerformed(evt);
            }
        });

        regAnularVenta.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regAnularVenta.setText("Anular Venta");
        regAnularVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regAnularVentaActionPerformed(evt);
            }
        });

        regAnularIng.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regAnularIng.setText("Anular Ingreso");
        regAnularIng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regAnularIngActionPerformed(evt);
            }
        });

        regInfoVenta.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regInfoVenta.setText("Info. Ventas realizadas");
        regInfoVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regInfoVentaActionPerformed(evt);
            }
        });

        regInfoIng.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regInfoIng.setText("Info. Ingresos realizados");
        regInfoIng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regInfoIngActionPerformed(evt);
            }
        });

        regRespaldarBD.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regRespaldarBD.setText("Respaldar BD");
        regRespaldarBD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regRespaldarBDActionPerformed(evt);
            }
        });

        regRestaurarBD.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regRestaurarBD.setText("Restaurar BD");
        regRestaurarBD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regRestaurarBDActionPerformed(evt);
            }
        });

        regInfoCaja.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regInfoCaja.setText("Info. de Caja");
        regInfoCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regInfoCajaActionPerformed(evt);
            }
        });

        regLotes.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        regLotes.setText("Reg. Lotes");
        regLotes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regLotesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(regProd, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(regIng, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(regVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(regProv, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(regCli, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(regCat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(regRol, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(regLotes, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(regInfoCaja, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regInfoVenta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regInfoIng, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regRespaldarBD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regRestaurarBD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regAnularIng, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regAnularVenta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(regIng)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regVenta)
                    .addComponent(regAnularVenta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regProd)
                    .addComponent(regAnularIng))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regProv)
                    .addComponent(regInfoVenta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regCli)
                    .addComponent(regInfoIng))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(regCat)
                    .addComponent(regRespaldarBD))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regRol)
                    .addComponent(regRestaurarBD))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regInfoCaja)
                    .addComponent(regLotes))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Nuevo / Modificar", jPanel2);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Acciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N
        jPanel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btnNuevo)
                .addGap(35, 35, 35)
                .addComponent(btnGuardar)
                .addGap(34, 34, 34)
                .addComponent(btnModificar)
                .addGap(26, 26, 26)
                .addComponent(btnCancelar)
                .addGap(30, 30, 30)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane2)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        Modificar = true; //declaro amodificar activado
        jTabbedPane2.setSelectedIndex(1); // se carga la segunda pestaña
        jTabbedPane2.setEnabledAt(1, true);
        jTabbedPane2.setEnabledAt(0, false);
        
        HabilitarBotones(); // se vuelve a habilitar los botones
        
        ClsRol clase = new ClsRol();
        RolDTO rol = new RolDTO();
        
        rol = clase.recuperarRol(CodRolMod); //se recrea el objeto usuario con sus atributos

        // se llena las cajas de texto
        this.textNombre.setText(rol.getNombre());
        this.jTextField3.setText(String.valueOf(rol.getId()));
        this.textNombre.setText(rol.getNombre());
        this.regIng.setSelected(rol.isRegIng());
        this.regVenta.setSelected(rol.isRegVenta());
        this.regProd.setSelected(rol.isRegProd());
        this.regProv.setSelected(rol.isRegProv());
        this.regCli.setSelected(rol.isRegCli());
        this.regCat.setSelected(rol.isRegCat());
        this.regRol.setSelected(rol.isRegRol());
        this.regAnularVenta.setSelected(rol.isAnularVenta());
        this.regAnularIng.setSelected(rol.isAnularIng());
        this.regInfoIng.setSelected(rol.isInfoIngreso());
        this.regInfoVenta.setSelected(rol.isInfoVenta());
        this.regRespaldarBD.setSelected(rol.isRespaldarBD());
        this.regRestaurarBD.setSelected(rol.isRestaurarBD());
        this.regInfoCaja.setSelected(rol.isInfoCaja());
        this.regLotes.setSelected(rol.isRegLote());
    }//GEN-LAST:event_btnModificarActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void textNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNombreActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void regIngActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regIngActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regIngActionPerformed

    private void regVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regVentaActionPerformed

    private void regProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regProdActionPerformed

    private void regProvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regProvActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regProvActionPerformed

    private void regCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regCliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regCliActionPerformed

    private void regCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regCatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regCatActionPerformed

    private void regRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regRolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regRolActionPerformed

    private void regAnularVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regAnularVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regAnularVentaActionPerformed

    private void regAnularIngActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regAnularIngActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regAnularIngActionPerformed

    private void regInfoVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regInfoVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regInfoVentaActionPerformed

    private void regInfoIngActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regInfoIngActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regInfoIngActionPerformed

    private void regRespaldarBDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regRespaldarBDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regRespaldarBDActionPerformed

    private void regRestaurarBDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regRestaurarBDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regRestaurarBDActionPerformed

    private void regInfoCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regInfoCajaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regInfoCajaActionPerformed

    private void regLotesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regLotesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regLotesActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0); // lleva a la pestaña 1
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        ClsRol clase = new ClsRol();
        int resp = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este usuario?", "Sistema de Ventas", 0,2);
        if(resp==0){
            
            if(clase.Eliminar(CodRolMod)){
                try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
             }
             HabilitarBotones();
                
            }
            else{
                JOptionPane.showMessageDialog(this,"No se puede eliminar porque existe un usuario con este rol. Elimine primero  al Usuario", "Sistema de ventas", 1);
            }     
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo = true; // se activa el nuevo
        jTabbedPane2.setSelectedIndex(1); // se redirecciona a la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones(); 
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        CodRolMod = Integer.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
        this.btnModificar.setEnabled(true);
        this.btnEliminar.setEnabled(true);// una vez seleccionado se habilita la tecla modificar
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        boolean verificar;
        if(Modificar) verificar = guardarModificado();//se pone modificar para evitar problemas con nuevo
        else verificar = guardarNuevo();
        
        if(verificar){
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0);
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones 
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(jRadioButton1.isSelected()){
            this.Buscar(); 
        }
        else if(jRadioButton2.isSelected()&&esNumero(jTextField1.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un ID valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JCheckBox regAnularIng;
    private javax.swing.JCheckBox regAnularVenta;
    private javax.swing.JCheckBox regCat;
    private javax.swing.JCheckBox regCli;
    private javax.swing.JCheckBox regInfoCaja;
    private javax.swing.JCheckBox regInfoIng;
    private javax.swing.JCheckBox regInfoVenta;
    private javax.swing.JCheckBox regIng;
    private javax.swing.JCheckBox regLotes;
    private javax.swing.JCheckBox regProd;
    private javax.swing.JCheckBox regProv;
    private javax.swing.JCheckBox regRespaldarBD;
    private javax.swing.JCheckBox regRestaurarBD;
    private javax.swing.JCheckBox regRol;
    private javax.swing.JCheckBox regVenta;
    private javax.swing.JTextField textNombre;
    // End of variables declaration//GEN-END:variables
}
