/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Dato.RolDTO;
import Dato.UsuarioDTO;
import Negocio.ClsUsuario;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import Negocio.ClsRol;
import java.time.LocalDate;


/**
 *
 * @author Sistema
 */
public class Form_Usuario extends javax.swing.JFrame {
    
    DefaultTableModel modelo;
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    private int CodUsuarioMod;
    
    /**
     * Creates new form form_rol
     */
    public Form_Usuario(){
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        jTabbedPane2.setEnabledAt(1,false);
        
        modelo= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        // declarar cabecera
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDO");
        modelo.addColumn("DOC");
        modelo.addColumn("DNI");
        modelo.addColumn("FECHA NAC");
        modelo.addColumn("EMAIL");
        modelo.addColumn("DIRECCION");       
        modelo.addColumn("TELEFONO");
        modelo.addColumn("USUARIO");
        modelo.addColumn("CONTRASEÑA");
        modelo.addColumn("ESTADO");
        modelo.addColumn("ID CARGO");
        modelo.addColumn("ID CARGO");
        modelo.addColumn("CARGO");

      
             
        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.tablaUsuario.setModel(modelo);
        
        this.OcultarColumnas(0);
        this.OcultarColumnas(3);
        this.OcultarColumnas(12);
        this.OcultarColumnas(13);
       
        
        // se acrtiva mostar por primera vez
        try {
            this.mostrar();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.HabilitarBotones();
        
        
        // se registra las opciones par ala lista desplegable de cargos
       ClsRol claseRol =new ClsRol();
       List<RolDTO> lista = new ArrayList();
        try {
           lista = claseRol.MostrarTodos();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        for (int i = 0; i<lista.size();i++) {
              listaTipos.addItem(lista.get(i));
        }
  
    
    }
  
        //limpia los cuadros de texto
       private void Limpiar(){
            this.textNombre.setText("");
            this.textApellido.setText("");
            this.textDni.setText("");
            this.textEmail.setText("");
            this.textpassword.setText("");
            this.textTelefono.setText("");
            this.dateUsuario.setText("");
            this.textDireccion.setText("");
            this.textUsuario.setText("");
        }
        // habilita botones dependido del estado de variables nuevo y modificar
        private void HabilitarBotones(){
            if(this.Nuevo || this.Modificar){
                this.btnNuevo.setEnabled(false);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(true);
                this.btnCancelar.setEnabled(true);
                this.btnSalir.setEnabled(false);

            } else{
                this.btnNuevo.setEnabled(true);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(false);
                this.btnCancelar.setEnabled(false);
                this.btnSalir.setEnabled(true);
            }

        }

        public boolean esNumero(String cadena) {

           boolean resultado;

           try {
               Integer.parseInt(cadena);
               resultado = true;
           } catch (NumberFormatException excepcion) {
               resultado = false;
           }
           return resultado;
       }


        //reduce lasdimenxsiones deun columna para aparentar que no existe
       private void OcultarColumnas(int a){
               tablaUsuario.getColumnModel().getColumn(a).setMaxWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setMinWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setPreferredWidth(0);
       }

       // funcion para imprimir la tabla
        private void mostrar() throws Exception{
             ClsUsuario clase = new ClsUsuario();
             for(int i=0;i<clase.MostrarSinFiltro(jCheckVerInactivos.isSelected()).size();i++)
             modelo.addRow(clase.MostrarSinFiltro(jCheckVerInactivos.isSelected()).get(i));
       }

        // funcion para ctualizar tabla 
         private void actualizarTabla() throws Exception{
             modelo.setRowCount(0);
             mostrar();

         }

        private void Buscar(){
            ClsUsuario clase = new ClsUsuario();
            modelo.setRowCount(0);


             if(jRadioNombre.isSelected() == true){
             String palabra = jTextField1.getText();
             for(int i=0;i<clase.buscar(palabra,jCheckVerInactivos.isSelected()).size();i++)
             modelo.addRow(clase.buscar(palabra,jCheckVerInactivos.isSelected()).get(i));


            }else{
             int palabra = Integer.valueOf(jTextField1.getText());
             for(int i=0;i<clase.buscarDni(palabra,jCheckVerInactivos.isSelected()).size();i++)
             modelo.addRow(clase.buscarDni(palabra,jCheckVerInactivos.isSelected()).get(i));   
            }    
        }

        private boolean guardarNuevo(){
            ClsUsuario clase = new ClsUsuario();
            UsuarioDTO usuario = new UsuarioDTO();

            if(textNombre.getText().equalsIgnoreCase("")|| textDni.getText().equalsIgnoreCase("")|| textUsuario.getText().equalsIgnoreCase("")|| textpassword.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Ventas",0);
            }
            else{

               if(esNumero(textDni.getText())){
               usuario.setNombre(textNombre.getText());
               usuario.setApellido(textApellido.getText());
               usuario.setEmail(textEmail.getText());

               if(dateUsuario.getDate()==null) usuario.setFechaNac(null);
               else usuario.setFechaNac(Date.valueOf(dateUsuario.getDate()));

               usuario.setDireccion(textDireccion.getText());
               usuario.setTelefono(textTelefono.getText());
               usuario.setUser(textUsuario.getText());
               usuario.setPass(textpassword.getText());
               usuario.setNumDoc(Integer.valueOf(textDni.getText()));
               usuario.setTipoDoc("DNI");

               if(estadoActivo.isSelected()==true) usuario.setEstado(true);
               else usuario.setEstado(false);

               RolDTO elejido = (RolDTO)listaTipos.getSelectedItem();
               usuario.setIdRol(elejido.getId());


               clase.GuardarNuevo(usuario);

               this.Limpiar();

               JOptionPane.showMessageDialog(this, "Usuario Creado.","Sistema de Ventas",1);    
               return true;
               } 
               else {
                   JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                   return false;
               } 
            }
           return false;         
        }

        private void inhabilitarUsuario(){

           ClsUsuario clase = new ClsUsuario();
           UsuarioDTO usuario = new UsuarioDTO();

           usuario = clase.recuperarUsuario(CodUsuarioMod); //se recrea el objeto usuario con sus atributos
           usuario.setEstado(false);

           clase.GuardarModificado(usuario);
           JOptionPane.showMessageDialog(this, "Usuario inhabilitado.","Sistema de Ventas",1);
        }

        private boolean guardarModificado(){
            ClsUsuario clase = new ClsUsuario();
            UsuarioDTO usuario = new UsuarioDTO();

            if(textNombre.getText().equalsIgnoreCase("")|| textDni.getText().equalsIgnoreCase("")|| textUsuario.getText().equalsIgnoreCase("")|| textpassword.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Ventas",0);
            }
            else{
                   if(esNumero(textDni.getText())){
                   usuario.setId(CodUsuarioMod);
                   usuario.setNombre(textNombre.getText());
                   usuario.setApellido(textApellido.getText());
                   usuario.setEmail(textEmail.getText());
                   if(dateUsuario.getDate()==null) usuario.setFechaNac(null);
                   else usuario.setFechaNac(Date.valueOf(dateUsuario.getDate()));
                   usuario.setDireccion(textDireccion.getText());
                   usuario.setTelefono(textTelefono.getText());
                   usuario.setUser(textUsuario.getText());
                   usuario.setPass(textpassword.getText());
                   usuario.setNumDoc(Integer.valueOf(textDni.getText()));
                   usuario.setTipoDoc("DNI");
                   if(estadoActivo.isSelected()==true) usuario.setEstado(true);
                   else usuario.setEstado(false);
                   RolDTO elejido = (RolDTO)listaTipos.getSelectedItem();
                   usuario.setIdRol(elejido.getId());


                   clase.GuardarModificado(usuario);


                   JOptionPane.showMessageDialog(this, "Usuario Modificado.","Sistema de Ventas",1);
                   return true;
                    }
                   else{
                       JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                       return false;
                   }
            }
           return false;     
        }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jRadioNombre = new javax.swing.JRadioButton();
        jTextField1 = new javax.swing.JTextField();
        jRadioDNI = new javax.swing.JRadioButton();
        btnBuscar = new javax.swing.JButton();
        jCheckVerInactivos = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaUsuario = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        textApellido = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textDni = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        textEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textUsuario = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textpassword = new javax.swing.JTextField();
        textTelefono = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textDireccion = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        estadoActivo = new javax.swing.JRadioButton();
        estadoInactivo = new javax.swing.JRadioButton();
        jLabel10 = new javax.swing.JLabel();
        listaTipos = new javax.swing.JComboBox();
        dateUsuario = new com.github.lgooddatepicker.components.DatePicker();
        jLabel11 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Usuario");

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(jRadioNombre);
        jRadioNombre.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioNombre.setSelected(true);
        jRadioNombre.setText("Nombre Usuario");
        jRadioNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioNombreActionPerformed(evt);
            }
        });

        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField1MouseClicked(evt);
            }
        });

        Grupo_Rol.add(jRadioDNI);
        jRadioDNI.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioDNI.setText("DNI");

        btnBuscar.setText("Buscar");
        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jCheckVerInactivos.setText("Ver inactivos");
        jCheckVerInactivos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jCheckVerInactivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckVerInactivosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jRadioNombre)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioDNI)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckVerInactivos)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioNombre)
                    .addComponent(jRadioDNI)
                    .addComponent(jCheckVerInactivos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnBuscar)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        tablaUsuario.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaUsuario.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tablaUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaUsuario.getTableHeader().setReorderingAllowed(false);
        tablaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuarioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaUsuario);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        jPanel2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanel2FocusGained(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        textNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNombreActionPerformed(evt);
            }
        });

        jLabel1.setText("*Nombre:");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textApellidoActionPerformed(evt);
            }
        });

        jLabel3.setText("Apellidos:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDniActionPerformed(evt);
            }
        });

        jLabel4.setText("*DNI:");
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textEmailActionPerformed(evt);
            }
        });

        jLabel5.setText("E-mail:");
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel6.setText("*Usuario:");
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textUsuarioActionPerformed(evt);
            }
        });

        jLabel7.setText("*Contraseña:");
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textpasswordActionPerformed(evt);
            }
        });

        textTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textTelefonoActionPerformed(evt);
            }
        });

        jLabel8.setText("Teléfono:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDireccion.setColumns(20);
        textDireccion.setRows(5);
        jScrollPane1.setViewportView(textDireccion);

        jLabel9.setText("Dirección:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Estado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        buttonGroup1.add(estadoActivo);
        estadoActivo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        estadoActivo.setSelected(true);
        estadoActivo.setText("Activo");
        estadoActivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estadoActivoActionPerformed(evt);
            }
        });

        buttonGroup1.add(estadoInactivo);
        estadoInactivo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        estadoInactivo.setText("Inactivo");
        estadoInactivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estadoInactivoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(estadoActivo)
                .addGap(18, 18, 18)
                .addComponent(estadoInactivo)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(estadoInactivo)
                    .addComponent(estadoActivo))
                .addGap(0, 2, Short.MAX_VALUE))
        );

        jLabel10.setText("Tipo de Usuario:");
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        listaTipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaTiposActionPerformed(evt);
            }
        });

        jLabel11.setText("Fech Nac:");
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(13, 13, 13))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(13, 13, 13))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel3))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(dateUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(textNombre)
                                        .addGap(93, 93, 93)))
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)
                                        .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(18, 18, 18)
                                        .addComponent(textTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textDni, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textApellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(textUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textpassword, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                                    .addComponent(listaTipos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addGap(32, 32, 32))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(textTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(dateUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(listaTipos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );

        jTabbedPane2.addTab("Nuevo / Modificar", jPanel2);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Acciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        btnNuevo.setText("Nuevo");
        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btnNuevo)
                .addGap(35, 35, 35)
                .addComponent(btnGuardar)
                .addGap(34, 34, 34)
                .addComponent(btnModificar)
                .addGap(26, 26, 26)
                .addComponent(btnCancelar)
                .addGap(38, 38, 38)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(76, 76, 76))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        
        
        
        Modificar = true; //declaro amodificar activado
        jTabbedPane2.setSelectedIndex(1); // se carga la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
  
        HabilitarBotones(); // se vuelve a habilitar los botones
        
        ClsUsuario clase = new ClsUsuario();
        UsuarioDTO usuario = new UsuarioDTO();

        usuario= clase.recuperarUsuario(CodUsuarioMod); //se recrea el objeto usuario con sus atributos
        

        // se llena las cajas de texto
        
        this.textNombre.setText(usuario.getNombre());
        this.textApellido.setText(usuario.getApellido());
            
        this.textDni.setText(String.valueOf(usuario.getNumDoc()));
        
        
        this.textEmail.setText(usuario.getEmail());
        this.textpassword.setText(usuario.getPass());
        this.textTelefono.setText(usuario.getTelefono());
        
        if(usuario.getEstado()) estadoActivo.setSelected(true);
        else estadoInactivo.setSelected(true);
        
        
        if(usuario.getFechaNac()==null){
            this.dateUsuario.setDate(null);
        }   
        else{
            Date date = usuario.getFechaNac();
            LocalDate fechNac = date.toLocalDate();
            this.dateUsuario.setDate(fechNac);
        }
        this.textDireccion.setText(usuario.getDireccion());
        this.textUsuario.setText(usuario.getUser());

        //se se llena con la lista desplegada en el objeto usuario
        for (int i = 0; i<listaTipos.getItemCount();i++) {
            RolDTO rol = (RolDTO)listaTipos.getItemAt(i);
     
            if(rol.getId()==usuario.getIdRol()) {
                listaTipos.setSelectedIndex(i);
            } 
        }
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void jRadioNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioNombreActionPerformed
        
    }//GEN-LAST:event_jRadioNombreActionPerformed

    private void textNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNombreActionPerformed

    private void textApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textApellidoActionPerformed

    private void textDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDniActionPerformed

    private void textEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textEmailActionPerformed

    private void textUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textUsuarioActionPerformed

    private void textpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textpasswordActionPerformed

    private void textTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textTelefonoActionPerformed

    private void estadoActivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estadoActivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estadoActivoActionPerformed

    private void estadoInactivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estadoInactivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estadoInactivoActionPerformed

    private void listaTiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaTiposActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_listaTiposActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(jRadioNombre.isSelected()){
            this.Buscar(); 
        }
        else if(jRadioDNI.isSelected()&&esNumero(jTextField1.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        boolean verificar;
        if(Modificar) verificar = guardarModificado();//se pone modificar para evitar problemas con nuevo
        else verificar = guardarNuevo();
        
        if(verificar){
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0);
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones 
        }
      
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void jPanel2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel2FocusGained

    }//GEN-LAST:event_jPanel2FocusGained

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo = true; // se activa el nuevo
        jTabbedPane2.setSelectedIndex(1); // se redirecciona a la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones();       
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0); // lleva a la pestaña 1
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        HabilitarBotones(); //se refresca la activacion de botones
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked
  
    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void tablaUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuarioMouseClicked
        CodUsuarioMod = Integer.valueOf(tablaUsuario.getValueAt(tablaUsuario.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
        this.btnModificar.setEnabled(true);
        this.btnEliminar.setEnabled(true);// una vez seleccionado se habilita la tecla modificar
    }//GEN-LAST:event_tablaUsuarioMouseClicked

    private void jTextField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MouseClicked
        
    }//GEN-LAST:event_jTextField1MouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        ClsUsuario clase = new ClsUsuario();
        int resp = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este usuario?", "Sistema de Ventas", 0,2);
        int resp2;  
        if(resp==0){
             if(!clase.Eliminar(CodUsuarioMod)){
                 resp2 = JOptionPane.showConfirmDialog(this,"No se puede eliminar el usuario por riesgo de perdida de infomación. ¿Desea inhabilitarlo?", "Sistema de Ventas",0,2);
                 if(resp2==0){
                    inhabilitarUsuario();
                 }    
             }      
             try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Usuario.class.getName()).log(Level.SEVERE, null, ex);
             }
             HabilitarBotones();
        }
   
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jCheckVerInactivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckVerInactivosActionPerformed
        if(jRadioNombre.isSelected()){
            this.Buscar(); 
        }
        else if(jRadioDNI.isSelected()&&esNumero(jTextField1.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_jCheckVerInactivosActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.github.lgooddatepicker.components.DatePicker dateUsuario;
    private javax.swing.JRadioButton estadoActivo;
    private javax.swing.JRadioButton estadoInactivo;
    private javax.swing.JCheckBox jCheckVerInactivos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JRadioButton jRadioDNI;
    private javax.swing.JRadioButton jRadioNombre;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JComboBox listaTipos;
    private javax.swing.JTable tablaUsuario;
    private javax.swing.JTextField textApellido;
    private javax.swing.JTextArea textDireccion;
    private javax.swing.JTextField textDni;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textNombre;
    private javax.swing.JTextField textTelefono;
    private javax.swing.JTextField textUsuario;
    private javax.swing.JTextField textpassword;
    // End of variables declaration//GEN-END:variables
}
